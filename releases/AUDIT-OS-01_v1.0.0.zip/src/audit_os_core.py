"""
AUDIT-OS-01: Visual API Contract & Webhook QA Workstation
Core Execution & Deterministic AST Schema Engine
"""

import json
import hmac
import hashlib
import time
import urllib.request
import urllib.error
import re
from typing import Dict, Any, List, Optional, Tuple, Union

class SchemaNode:
    def __init__(self, node_type: str, properties: Optional[Dict[str, 'SchemaNode']] = None,
                 items: Optional[Union['SchemaNode', List['SchemaNode']]] = None,
                 nullable: bool = False, optional: bool = False,
                 enum_values: Optional[List[Any]] = None):
        self.node_type = node_type # 'string', 'integer', 'float', 'boolean', 'null', 'object', 'array', 'union'
        self.properties = properties or {}
        self.items = items
        self.nullable = nullable
        self.optional = optional
        self.enum_values = enum_values or []

    def to_dict(self) -> Dict[str, Any]:
        d = {
            "type": self.node_type,
            "nullable": self.nullable,
            "optional": self.optional
        }
        if self.properties:
            d["properties"] = {k: v.to_dict() for k, v in self.properties.items()}
        if self.items:
            if isinstance(self.items, list):
                d["items"] = [i.to_dict() for i in self.items]
            else:
                d["items"] = self.items.to_dict()
        if self.enum_values:
            d["enum"] = self.enum_values
        return d

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'SchemaNode':
        node_type = data.get("type", "object")
        nullable = data.get("nullable", False)
        optional = data.get("optional", False)
        enum_values = data.get("enum", [])
        
        properties = {}
        if "properties" in data:
            for k, v in data["properties"].items():
                properties[k] = cls.from_dict(v)
                
        items = None
        if "items" in data:
            if isinstance(data["items"], list):
                items = [cls.from_dict(i) for i in data["items"]]
            elif isinstance(data["items"], dict):
                items = cls.from_dict(data["items"])
                
        return cls(node_type, properties=properties, items=items,
                   nullable=nullable, optional=optional, enum_values=enum_values)


class AstSchemaEngine:
    """Deterministic AST Schema Inferrer and Structural Diff Comparator."""
    
    @staticmethod
    def infer_schema(data: Any, optional: bool = False) -> SchemaNode:
        if data is None:
            return SchemaNode("null", nullable=True, optional=optional)
        elif isinstance(data, bool):
            return SchemaNode("boolean", optional=optional)
        elif isinstance(data, int):
            return SchemaNode("integer", optional=optional)
        elif isinstance(data, float):
            return SchemaNode("float", optional=optional)
        elif isinstance(data, str):
            return SchemaNode("string", optional=optional)
        elif isinstance(data, list):
            if not data:
                return SchemaNode("array", items=SchemaNode("any"), optional=optional)
            # Infer item schemas
            item_schemas = [AstSchemaEngine.infer_schema(x) for x in data]
            # Check if all items share the exact same type
            first_type = item_schemas[0].node_type
            if all(s.node_type == first_type for s in item_schemas):
                if first_type == "object":
                    # Merge properties across array items
                    merged_props = {}
                    for item in data:
                        if isinstance(item, dict):
                            for k, v in item.items():
                                if k not in merged_props:
                                    merged_props[k] = AstSchemaEngine.infer_schema(v)
                    return SchemaNode("array", items=SchemaNode("object", properties=merged_props), optional=optional)
                else:
                    return SchemaNode("array", items=item_schemas[0], optional=optional)
            else:
                # Heterogeneous tuple/union array
                return SchemaNode("array", items=item_schemas, optional=optional)
        elif isinstance(data, dict):
            properties = {}
            for k, v in data.items():
                properties[str(k)] = AstSchemaEngine.infer_schema(v)
            return SchemaNode("object", properties=properties, optional=optional)
        else:
            return SchemaNode("string", optional=optional)

    @staticmethod
    def diff_schemas(baseline: SchemaNode, incoming: SchemaNode, path: str = "$") -> List[Dict[str, Any]]:
        """
        Deterministic Structural Mutation Comparator.
        Classifies changes as BREAKING vs NON_BREAKING based on concrete type contracts.
        """
        diffs = []
        
        # 1. Nullability Violation
        if not baseline.nullable and incoming.node_type == "null":
            diffs.append({
                "path": path,
                "type": "NULLABLE_VIOLATION",
                "severity": "BREAKING",
                "message": f"Field '{path}' is non-nullable in baseline, but received null value."
            })
            return diffs

        # 2. Type Mutation
        if baseline.node_type != incoming.node_type and incoming.node_type != "null":
            # Allow integer to float promotion gracefully as non-breaking, otherwise breaking
            if baseline.node_type == "integer" and incoming.node_type == "float":
                diffs.append({
                    "path": path,
                    "type": "NUMERIC_WIDENING",
                    "severity": "NON_BREAKING",
                    "message": f"Field '{path}' widened from integer to float."
                })
            else:
                diffs.append({
                    "path": path,
                    "type": "TYPE_MUTATION",
                    "severity": "BREAKING",
                    "message": f"Field '{path}' type mutated from {baseline.node_type} to {incoming.node_type}."
                })
            return diffs

        # 3. Object Properties Diff
        if baseline.node_type == "object" and incoming.node_type == "object":
            base_keys = set(baseline.properties.keys())
            inc_keys = set(incoming.properties.keys())
            
            # Check for Removed Fields
            for k in base_keys:
                if k not in inc_keys:
                    is_opt = baseline.properties[k].optional
                    diffs.append({
                        "path": f"{path}.{k}",
                        "type": "FIELD_REMOVED",
                        "severity": "NON_BREAKING" if is_opt else "BREAKING",
                        "message": f"Field '{k}' was removed from object at '{path}'."
                    })
                else:
                    diffs.extend(AstSchemaEngine.diff_schemas(
                        baseline.properties[k], incoming.properties[k], path=f"{path}.{k}"
                    ))
                    
            # Check for Added Fields
            for k in inc_keys:
                if k not in base_keys:
                    diffs.append({
                        "path": f"{path}.{k}",
                        "type": "FIELD_ADDED",
                        "severity": "NON_BREAKING",
                        "message": f"New field '{k}' detected at '{path}'."
                    })

        # 4. Array Items Diff
        if baseline.node_type == "array" and incoming.node_type == "array":
            if baseline.items and incoming.items:
                if isinstance(baseline.items, SchemaNode) and isinstance(incoming.items, SchemaNode):
                    diffs.extend(AstSchemaEngine.diff_schemas(
                        baseline.items, incoming.items, path=f"{path}[]"
                    ))
                elif isinstance(baseline.items, list) and isinstance(incoming.items, list):
                    if len(baseline.items) != len(incoming.items):
                        diffs.append({
                            "path": path,
                            "type": "TUPLE_LENGTH_MISMATCH",
                            "severity": "BREAKING",
                            "message": f"Array tuple length changed from {len(baseline.items)} to {len(incoming.items)}."
                        })
                    else:
                        for i, (b_item, inc_item) in enumerate(zip(baseline.items, incoming.items)):
                            diffs.extend(AstSchemaEngine.diff_schemas(
                                b_item, inc_item, path=f"{path}[{i}]"
                            ))

        return diffs


class CodeGenerator:
    """Deterministic Code Generator for TypeScript, Zod, and Python Pydantic."""
    
    @staticmethod
    def to_pascal_case(name: str) -> str:
        words = re.split(r'[^a-zA-Z0-9]+', name)
        result = ""
        for w in words:
            if not w:
                continue
            if re.search(r'[a-z][A-Z]', w):
                result += w[0].upper() + w[1:]
            else:
                result += w[0].upper() + w[1:].lower() if len(w) > 1 else w.upper()
        return result or "GeneratedModel"

    @staticmethod
    def generate_typescript(node: SchemaNode, name: str = "PayloadModel") -> str:
        pascal_name = CodeGenerator.to_pascal_case(name)
        nested_interfaces = []
        
        def render_type(n: SchemaNode, prop_name: str) -> str:
            if n.node_type == "string":
                return "string"
            elif n.node_type in ("integer", "float"):
                return "number"
            elif n.node_type == "boolean":
                return "boolean"
            elif n.node_type == "null":
                return "null"
            elif n.node_type == "array":
                if isinstance(n.items, SchemaNode):
                    item_t = render_type(n.items, f"{prop_name}Item")
                    return f"{item_t}[]"
                elif isinstance(n.items, list):
                    item_types = [render_type(i, f"{prop_name}Item{idx}") for idx, i in enumerate(n.items)]
                    return f"[{', '.join(item_types)}]"
                return "any[]"
            elif n.node_type == "object":
                sub_name = CodeGenerator.to_pascal_case(prop_name)
                props_str = []
                for k, v in n.properties.items():
                    opt_mark = "?" if v.optional else ""
                    type_str = render_type(v, k)
                    if v.nullable:
                        type_str += " | null"
                    safe_k = k if re.match(r'^[a-zA-Z_$][a-zA-Z0-9_$]*$', k) else f'"{k}"'
                    props_str.append(f"  {safe_k}{opt_mark}: {type_str};")
                nested_interfaces.append(
                    f"export interface {sub_name} {{\n" + "\n".join(props_str) + "\n}"
                )
                return sub_name
            return "any"

        root_props = []
        if node.node_type == "object":
            for k, v in node.properties.items():
                opt_mark = "?" if v.optional else ""
                type_str = render_type(v, k)
                if v.nullable:
                    type_str += " | null"
                safe_k = k if re.match(r'^[a-zA-Z_$][a-zA-Z0-9_$]*$', k) else f'"{k}"'
                root_props.append(f"  {safe_k}{opt_mark}: {type_str};")
            root_interface = f"export interface {pascal_name} {{\n" + "\n".join(root_props) + "\n}"
        else:
            root_interface = f"export type {pascal_name} = {render_type(node, name)};"
            
        all_code = nested_interfaces + [root_interface]
        return "\n\n".join(all_code)

    @staticmethod
    def generate_zod(node: SchemaNode, name: str = "PayloadModel") -> str:
        pascal_name = CodeGenerator.to_pascal_case(name)
        
        def render_zod(n: SchemaNode) -> str:
            expr = "z.any()"
            if n.node_type == "string":
                expr = "z.string()"
            elif n.node_type in ("integer", "float"):
                expr = "z.number()"
            elif n.node_type == "boolean":
                expr = "z.boolean()"
            elif n.node_type == "null":
                expr = "z.null()"
            elif n.node_type == "array":
                if isinstance(n.items, SchemaNode):
                    expr = f"z.array({render_zod(n.items)})"
                elif isinstance(n.items, list):
                    tuple_args = ", ".join(render_zod(i) for i in n.items)
                    expr = f"z.tuple([{tuple_args}])"
                else:
                    expr = "z.array(z.any())"
            elif n.node_type == "object":
                props_str = []
                for k, v in n.properties.items():
                    z_val = render_zod(v)
                    if v.nullable:
                        z_val = f"{z_val}.nullable()"
                    if v.optional:
                        z_val = f"{z_val}.optional()"
                    safe_k = k if re.match(r'^[a-zA-Z_$][a-zA-Z0-9_$]*$', k) else f'"{k}"'
                    props_str.append(f"  {safe_k}: {z_val},")
                expr = "z.object({\n" + "\n".join(props_str) + "\n})"

            return expr

        zod_def = f"export const {pascal_name}Schema = {render_zod(node)};\n"
        zod_def += f"export type {pascal_name} = z.infer<typeof {pascal_name}Schema>;"
        return f"import {{ z }} from 'zod';\n\n{zod_def}"

    @staticmethod
    def generate_pydantic(node: SchemaNode, name: str = "PayloadModel") -> str:
        pascal_name = CodeGenerator.to_pascal_case(name)
        models = []
        
        def render_pydantic_type(n: SchemaNode, prop_name: str) -> str:
            if n.node_type == "string":
                t = "str"
            elif n.node_type == "integer":
                t = "int"
            elif n.node_type == "float":
                t = "float"
            elif n.node_type == "boolean":
                t = "bool"
            elif n.node_type == "null":
                t = "None"
            elif n.node_type == "array":
                if isinstance(n.items, SchemaNode):
                    sub_t = render_pydantic_type(n.items, f"{prop_name}Item")
                    t = f"List[{sub_t}]"
                elif isinstance(n.items, list):
                    tuple_types = [render_pydantic_type(i, f"{prop_name}Item{idx}") for idx, i in enumerate(n.items)]
                    t = f"Tuple[{', '.join(tuple_types)}]"
                else:
                    t = "List[Any]"
            elif n.node_type == "object":
                sub_model_name = CodeGenerator.to_pascal_case(prop_name)
                fields = []
                for k, v in n.properties.items():
                    field_t = render_pydantic_type(v, k)
                    if v.nullable or v.optional:
                        field_t = f"Optional[{field_t}] = None"
                    safe_k = k if k.isidentifier() else f"field_{k}"
                    fields.append(f"    {safe_k}: {field_t}")
                models.append(f"class {sub_model_name}(BaseModel):\n" + ("\n".join(fields) if fields else "    pass"))
                return sub_model_name
            else:
                t = "Any"
            return t

        root_fields = []
        if node.node_type == "object":
            for k, v in node.properties.items():
                field_t = render_pydantic_type(v, k)
                if v.nullable or v.optional:
                    field_t = f"Optional[{field_t}] = None"
                safe_k = k if k.isidentifier() else f"field_{k}"
                root_fields.append(f"    {safe_k}: {field_t}")
            models.append(f"class {pascal_name}(BaseModel):\n" + ("\n".join(root_fields) if root_fields else "    pass"))
        else:
            models.append(f"class {pascal_name}(BaseModel):\n    value: {render_pydantic_type(node, 'value')}")

        header = "from typing import Optional, List, Dict, Any, Tuple\nfrom pydantic import BaseModel, Field\n\n"
        return header + "\n\n".join(models)


class PayloadReplayer:
    """Dispatches parameterized HTTP requests to target endpoints with safety guards."""
    
    @staticmethod
    def replay(target_url: str, method: str, headers: Dict[str, str], body: str,
               confirmed_safety: bool = False, timeout_seconds: int = 5) -> Dict[str, Any]:
        
        is_localhost = any(target_url.startswith(prefix) for prefix in [
            "http://localhost", "http://127.0.0.1", "http://[::1]",
            "https://localhost", "https://127.0.0.1"
        ])
        
        if not is_localhost and not confirmed_safety:
            return {
                "success": False,
                "error": "NON_LOCALHOST_CONFIRMATION_REQUIRED",
                "message": "Replay target is not localhost. Explicit safety confirmation required."
            }
            
        start_time = time.time()
        req_headers = {k: v for k, v in headers.items() if k.lower() not in ("host", "content-length")}
        req_data = body.encode("utf-8") if body else None
        
        req = urllib.request.Request(target_url, data=req_data, headers=req_headers, method=method.upper())
        
        try:
            with urllib.request.urlopen(req, timeout=timeout_seconds) as response:
                duration_ms = int((time.time() - start_time) * 1000)
                res_body = response.read().decode("utf-8", errors="replace")
                res_headers = dict(response.getheaders())
                return {
                    "success": True,
                    "status_code": response.status,
                    "headers": res_headers,
                    "body": res_body,
                    "duration_ms": duration_ms
                }
        except urllib.error.HTTPError as e:
            duration_ms = int((time.time() - start_time) * 1000)
            res_body = e.read().decode("utf-8", errors="replace")
            return {
                "success": True,
                "status_code": e.code,
                "headers": dict(e.headers),
                "body": res_body,
                "duration_ms": duration_ms
            }
        except Exception as e:
            duration_ms = int((time.time() - start_time) * 1000)
            return {
                "success": False,
                "error": "CONNECTION_FAILED",
                "message": str(e),
                "duration_ms": duration_ms
            }


class MockServerCompiler:
    """Compiles zero-dependency standalone Node.js and Python mock servers."""
    
    @staticmethod
    def compile_nodejs(routes: Dict[str, Dict[str, Any]], port: int = 4000) -> str:
        routes_json = json.dumps(routes, indent=2)
        return f"""/**
 * AUDIT-OS-01 Standalone Node.js Mock API Server
 * Generated on {time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}
 * Run: node mock_server.js --port {port}
 */
const http = require('http');

const PORT = process.argv.includes('--port') ? parseInt(process.argv[process.argv.indexOf('--port') + 1], 10) : {port};
const ROUTES = {routes_json};

const server = http.createServer((req, res) => {{
  const method = req.method.toUpperCase();
  const urlPath = req.url.split('?')[0];
  const key = `\${{method}} \${{urlPath}}`;
  
  console.log(`[\${{new Date().toISOString()}}] \${{method}} \${{urlPath}}`);
  
  if (ROUTES[key]) {{
    const r = ROUTES[key];
    res.writeHead(r.status || 200, r.headers || {{ 'Content-Type': 'application/json' }});
    const bodyStr = typeof r.body === 'string' ? r.body : JSON.stringify(r.body);
    res.end(bodyStr);
  }} else {{
    res.writeHead(404, {{ 'Content-Type': 'application/json' }});
    res.end(JSON.stringify({{ error: 'Mock route not configured', requested: key }}));
  }}
}});

server.listen(PORT, () => {{
  console.log(`🚀 AUDIT-OS-01 Mock Server listening on http://localhost:\${{PORT}}`);
}});
"""

    @staticmethod
    def compile_python(routes: Dict[str, Dict[str, Any]], port: int = 4000) -> str:
        routes_json = json.dumps(routes, indent=2)
        return f"""# AUDIT-OS-01 Standalone Python Mock API Server
# Generated on {time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}
# Run: python mock_server.py --port {port}

import sys
import json
from http.server import HTTPServer, BaseHTTPRequestHandler

PORT = {port}
if '--port' in sys.argv:
    PORT = int(sys.argv[sys.argv.index('--port') + 1])

ROUTES = {routes_json}

class MockHandler(BaseHTTPRequestHandler):
    def do_GET(self): self._handle('GET')
    def do_POST(self): self._handle('POST')
    def do_PUT(self): self._handle('PUT')
    def do_PATCH(self): self._handle('PATCH')
    def do_DELETE(self): self._handle('DELETE')

    def _handle(self, method):
        url_path = self.path.split('?')[0]
        key = f"{{method}} {{url_path}}"
        print(f"[AUDIT-OS-01 Mock] {{method}} {{url_path}}")
        if key in ROUTES:
            r = ROUTES[key]
            status = r.get('status', 200)
            headers = r.get('headers', {{'Content-Type': 'application/json'}})
            body = r.get('body', {{}})
            body_bytes = (body if isinstance(body, str) else json.dumps(body)).encode('utf-8')
            
            self.send_response(status)
            for h_k, h_v in headers.items():
                self.send_header(h_k, h_v)
            self.end_headers()
            self.wfile.write(body_bytes)
        else:
            self.send_response(404)
            self.send_header('Content-Type', 'application/json')
            self.end_headers()
            self.wfile.write(json.dumps({{'error': 'Mock route not found', 'requested': key}}).encode('utf-8'))

print(f"🚀 AUDIT-OS-01 Python Mock Server listening on http://localhost:{{PORT}}")
HTTPServer(('0.0.0.0', PORT), MockHandler).serve_forever()
"""


class HmacVerifier:
    """HMAC Webhook Signature Verification Sandbox."""
    
    @staticmethod
    def verify_signature(raw_payload: str, secret: str, received_signature: str,
                         header_format: str = "stripe", format: Optional[str] = None) -> Dict[str, Any]:
        """
        Supports Stripe (t=...,v1=...), Shopify (Base64 sha256), GitHub (sha256=...), and Standard Hex.
        """
        fmt = (format or header_format or "stripe").lower()
        if not secret or not received_signature:
            return {"valid": False, "error": "MISSING_SECRET_OR_SIGNATURE"}

        try:
            if fmt == "stripe":
                # Extract t=timestamp and v1=signature
                parts = dict(item.split("=", 1) for item in received_signature.split(",") if "=" in item)
                timestamp = parts.get("t", "")
                sig_v1 = parts.get("v1", "")
                if not timestamp or not sig_v1:
                    return {"valid": False, "error": "MALFORMED_STRIPE_HEADER"}
                signed_payload = f"{timestamp}.{raw_payload}".encode("utf-8")
                expected_sig = hmac.new(secret.encode("utf-8"), signed_payload, hashlib.sha256).hexdigest()
                is_valid = hmac.compare_digest(expected_sig, sig_v1)
                return {"valid": is_valid, "expected": expected_sig, "received": sig_v1, "timestamp": timestamp}

            elif header_format.lower() == "shopify":
                import base64
                expected_sig = base64.b64encode(hmac.new(secret.encode("utf-8"), raw_payload.encode("utf-8"), hashlib.sha256).digest()).decode("utf-8")
                is_valid = hmac.compare_digest(expected_sig, received_signature)
                return {"valid": is_valid, "expected": expected_sig, "received": received_signature}

            elif header_format.lower() == "github":
                sig_clean = received_signature.replace("sha256=", "").strip()
                expected_sig = hmac.new(secret.encode("utf-8"), raw_payload.encode("utf-8"), hashlib.sha256).hexdigest()
                is_valid = hmac.compare_digest(expected_sig, sig_clean)
                return {"valid": is_valid, "expected": expected_sig, "received": sig_clean}

            else:
                # Standard Hex HMAC-SHA256
                expected_sig = hmac.new(secret.encode("utf-8"), raw_payload.encode("utf-8"), hashlib.sha256).hexdigest()
                is_valid = hmac.compare_digest(expected_sig, received_signature.strip())
                return {"valid": is_valid, "expected": expected_sig, "received": received_signature}

        except Exception as e:
            return {"valid": False, "error": str(e)}


class RedactionFilter:
    """Masks sensitive headers, credentials, and PII in payloads."""
    
    SENSITIVE_HEADERS = {"authorization", "cookie", "set-cookie", "x-api-key", "x-auth-token", "stripe-signature"}
    
    @staticmethod
    def redact_headers(headers: Dict[str, str]) -> Dict[str, str]:
        redacted = {}
        for k, v in headers.items():
            if k.lower() in RedactionFilter.SENSITIVE_HEADERS:
                redacted[k] = "REDACTED_BY_AUDIT_OS"
            else:
                redacted[k] = v
        return redacted
