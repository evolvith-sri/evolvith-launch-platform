"""
AUDIT-OS-01: Local SQLite Sovereign Database Layer
"""

import sqlite3
import json
import time
import os
from typing import Dict, Any, List, Optional

class AuditDatabase:
    def __init__(self, db_path: str = "data/audit_store.db"):
        self.db_path = db_path
        os.makedirs(os.path.dirname(os.path.abspath(db_path)), exist_ok=True)
        self._init_schema()

    def _get_connection(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode = WAL;")
        conn.execute("PRAGMA synchronous = NORMAL;")
        return conn

    def _init_schema(self):
        with self._get_connection() as conn:
            conn.executescript("""
            CREATE TABLE IF NOT EXISTS projects (
                project_id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                description TEXT,
                created_at INTEGER NOT NULL,
                updated_at INTEGER NOT NULL
            );

            CREATE TABLE IF NOT EXISTS webhook_traps (
                trap_id TEXT PRIMARY KEY,
                project_id TEXT NOT NULL,
                name TEXT NOT NULL,
                token TEXT NOT NULL,
                public_url TEXT NOT NULL,
                target_localhost_url TEXT,
                auto_forward BOOLEAN NOT NULL DEFAULT 0,
                hmac_secret TEXT,
                hmac_header TEXT,
                created_at INTEGER NOT NULL,
                FOREIGN KEY (project_id) REFERENCES projects(project_id) ON DELETE CASCADE
            );

            CREATE TABLE IF NOT EXISTS captured_events (
                event_id TEXT PRIMARY KEY,
                trap_id TEXT NOT NULL,
                http_method TEXT NOT NULL,
                source_ip TEXT,
                query_params TEXT,
                headers TEXT NOT NULL,
                raw_body TEXT NOT NULL,
                body_json TEXT,
                content_type TEXT NOT NULL,
                content_length INTEGER NOT NULL,
                received_at INTEGER NOT NULL,
                FOREIGN KEY (trap_id) REFERENCES webhook_traps(trap_id) ON DELETE CASCADE
            );
            CREATE INDEX IF NOT EXISTS idx_events_trap_time ON captured_events(trap_id, received_at DESC);

            CREATE TABLE IF NOT EXISTS schema_baselines (
                schema_id TEXT PRIMARY KEY,
                project_id TEXT NOT NULL,
                event_name TEXT NOT NULL,
                version INTEGER NOT NULL DEFAULT 1,
                inferred_ast TEXT NOT NULL,
                json_schema TEXT NOT NULL,
                created_at INTEGER NOT NULL,
                updated_at INTEGER NOT NULL,
                FOREIGN KEY (project_id) REFERENCES projects(project_id) ON DELETE CASCADE
            );
            CREATE UNIQUE INDEX IF NOT EXISTS idx_schema_project_event ON schema_baselines(project_id, event_name, version);

            CREATE TABLE IF NOT EXISTS schema_diff_logs (
                diff_id TEXT PRIMARY KEY,
                event_id TEXT NOT NULL,
                schema_id TEXT NOT NULL,
                is_breaking BOOLEAN NOT NULL,
                diff_summary TEXT NOT NULL,
                analyzed_at INTEGER NOT NULL,
                FOREIGN KEY (event_id) REFERENCES captured_events(event_id) ON DELETE CASCADE,
                FOREIGN KEY (schema_id) REFERENCES schema_baselines(schema_id) ON DELETE CASCADE
            );

            CREATE TABLE IF NOT EXISTS replay_history (
                replay_id TEXT PRIMARY KEY,
                event_id TEXT NOT NULL,
                target_url TEXT NOT NULL,
                http_method TEXT NOT NULL,
                sent_headers TEXT NOT NULL,
                sent_body TEXT NOT NULL,
                response_status INTEGER,
                response_headers TEXT,
                response_body TEXT,
                duration_ms INTEGER,
                executed_at INTEGER NOT NULL,
                FOREIGN KEY (event_id) REFERENCES captured_events(event_id) ON DELETE CASCADE
            );

            CREATE TABLE IF NOT EXISTS app_settings (
                key TEXT PRIMARY KEY,
                value TEXT NOT NULL,
                updated_at INTEGER NOT NULL
            );
            """)

    def insert_project(self, project_id: str, name: str, description: str = ""):
        now = int(time.time() * 1000)
        with self._get_connection() as conn:
            conn.execute(
                "INSERT OR REPLACE INTO projects (project_id, name, description, created_at, updated_at) VALUES (?, ?, ?, ?, ?)",
                (project_id, name, description, now, now)
            )

    def insert_trap(self, trap_id: str, project_id: str, name: str, token: str, public_url: str,
                    target_localhost_url: str = "", hmac_secret: str = "", hmac_header: str = "stripe"):
        now = int(time.time() * 1000)
        with self._get_connection() as conn:
            conn.execute(
                """INSERT OR REPLACE INTO webhook_traps 
                (trap_id, project_id, name, token, public_url, target_localhost_url, hmac_secret, hmac_header, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (trap_id, project_id, name, token, public_url, target_localhost_url, hmac_secret, hmac_header, now)
            )

    def insert_event(self, event_id: str, trap_id: str, method: str, headers: Dict[str, str],
                     raw_body: str, source_ip: str = "127.0.0.1", query_params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        now = int(time.time() * 1000)
        body_json_str = None
        try:
            parsed = json.loads(raw_body)
            body_json_str = json.dumps(parsed)
        except Exception:
            pass

        content_type = headers.get("content-type", headers.get("Content-Type", "application/json"))
        headers_str = json.dumps(headers)
        query_str = json.dumps(query_params or {})

        with self._get_connection() as conn:
            conn.execute(
                """INSERT INTO captured_events 
                (event_id, trap_id, http_method, source_ip, query_params, headers, raw_body, body_json, content_type, content_length, received_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (event_id, trap_id, method.upper(), source_ip, query_str, headers_str, raw_body, body_json_str, content_type, len(raw_body), now)
            )
        return {
            "event_id": event_id,
            "trap_id": trap_id,
            "http_method": method.upper(),
            "received_at": now,
            "content_length": len(raw_body)
        }

    def get_events(self, trap_id: str, limit: int = 50) -> List[Dict[str, Any]]:
        with self._get_connection() as conn:
            cur = conn.execute(
                "SELECT * FROM captured_events WHERE trap_id = ? ORDER BY received_at DESC LIMIT ?",
                (trap_id, limit)
            )
            rows = cur.fetchall()
            events = []
            for r in rows:
                ev = dict(r)
                ev["headers"] = json.loads(ev["headers"])
                ev["query_params"] = json.loads(ev["query_params"])
                if ev["body_json"]:
                    ev["body_json"] = json.loads(ev["body_json"])
                events.append(ev)
            return events

    def vacuum(self):
        with self._get_connection() as conn:
            conn.execute("VACUUM;")
