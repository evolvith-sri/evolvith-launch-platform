"""
AUDIT-OS-01: Command Line Interface & Local Harness
"""

import sys
import os
import json
import argparse
from audit_os_core import AstSchemaEngine, CodeGenerator, PayloadReplayer, MockServerCompiler, HmacVerifier
from audit_db import AuditDatabase

def main():
    parser = argparse.ArgumentParser(description="AUDIT-OS-01: Visual API Contract & Webhook QA Workstation CLI")
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # 1. Infer Schema
    infer_parser = subparsers.add_parser("infer", help="Infer AST schema from JSON file")
    infer_parser.add_argument("--file", required=True, help="Path to sample JSON payload")

    # 2. Diff Schemas
    diff_parser = subparsers.add_parser("diff", help="Diff two JSON payloads or schemas")
    diff_parser.add_argument("--baseline", required=True, help="Baseline JSON file")
    diff_parser.add_argument("--incoming", required=True, help="Incoming JSON file")

    # 3. Generate Code
    codegen_parser = subparsers.add_parser("codegen", help="Generate TypeScript, Zod, or Pydantic models")
    codegen_parser.add_argument("--file", required=True, help="JSON payload file")
    codegen_parser.add_argument("--lang", choices=["ts", "zod", "pydantic"], default="ts", help="Target language")
    codegen_parser.add_argument("--name", default="WebhookEvent", help="Target Model Name")

    # 4. Replay
    replay_parser = subparsers.add_parser("replay", help="Replay a JSON payload to a target URL")
    replay_parser.add_argument("--url", required=True, help="Target URL (e.g. http://localhost:3000/api/webhook)")
    replay_parser.add_argument("--file", required=True, help="JSON payload file")
    replay_parser.add_argument("--confirm-remote", action="store_true", help="Explicit confirmation for non-localhost URLs")

    # 5. Mock Server
    mock_parser = subparsers.add_parser("mock", help="Export a standalone mock server script")
    mock_parser.add_argument("--file", required=True, help="JSON mock routes definition")
    mock_parser.add_argument("--out", default="mock_server.js", help="Output filename")
    mock_parser.add_argument("--lang", choices=["node", "python"], default="node", help="Script runtime")
    mock_parser.add_argument("--port", type=int, default=4000, help="Mock server port")

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        sys.exit(1)

    if args.command == "infer":
        with open(args.file, "r", encoding="utf-8") as f:
            data = json.load(f)
        schema = AstSchemaEngine.infer_schema(data)
        print(json.dumps(schema.to_dict(), indent=2))

    elif args.command == "diff":
        with open(args.baseline, "r", encoding="utf-8") as f:
            b_data = json.load(f)
        with open(args.incoming, "r", encoding="utf-8") as f:
            i_data = json.load(f)
        b_schema = AstSchemaEngine.infer_schema(b_data)
        i_schema = AstSchemaEngine.infer_schema(i_data)
        diffs = AstSchemaEngine.diff_schemas(b_schema, i_schema)
        print(json.dumps(diffs, indent=2))

    elif args.command == "codegen":
        with open(args.file, "r", encoding="utf-8") as f:
            data = json.load(f)
        schema = AstSchemaEngine.infer_schema(data)
        if args.lang == "ts":
            code = CodeGenerator.generate_typescript(schema, args.name)
        elif args.lang == "zod":
            code = CodeGenerator.generate_zod(schema, args.name)
        else:
            code = CodeGenerator.generate_pydantic(schema, args.name)
        print(code)

    elif args.command == "replay":
        with open(args.file, "r", encoding="utf-8") as f:
            body = f.read()
        res = PayloadReplayer.replay(args.url, "POST", {"Content-Type": "application/json"}, body, confirmed_safety=args.confirm_remote)
        print(json.dumps(res, indent=2))

    elif args.command == "mock":
        with open(args.file, "r", encoding="utf-8") as f:
            routes = json.load(f)
        if args.lang == "node":
            script = MockServerCompiler.compile_nodejs(routes, port=args.port)
        else:
            script = MockServerCompiler.compile_python(routes, port=args.port)
        with open(args.out, "w", encoding="utf-8") as f:
            f.write(script)
        print(f"✅ Mock server script written to {args.out}")

if __name__ == "__main__":
    main()
