# 48-Hour Rapid Installation Runbook: AUDIT-OS-01

## Hour 00–12: Installation & Workspace Initialization
1. Unpack `AUDIT-OS-01_v1.0.0.zip`.
2. Run `python install.py` to verify environment and initialize local database.
3. Configure `AUDIT_DB_PATH` in `.env` if custom storage directory is preferred.

## Hour 12–24: Webhook Trap Setup & Test Stream
1. Open the workstation interface or run `python src/audit_cli.py`.
2. Create first webhook trap and paste public URL into Stripe/Shopify test webhooks.
3. Send sample event and confirm receipt.

## Hour 24–36: Baseline Schema & Type Generation
1. Capture initial payloads and establish `Baseline v1`.
2. Export TypeScript interfaces or Zod schemas directly into your application codebase.

## Hour 36–48: Localhost Replay & CI Mock Integration
1. Configure local target URL (e.g. `http://localhost:3000/api/webhook`).
2. Replay test events to verify local application handlers.
3. Export standalone mock server for frontend team testing.
