# AUDIT-OS-01 API Specification

## 1. Webhook Trap Ingestion Endpoint
* **URL**: `POST https://trap.evolvith.com/v1/inbound/{trap_id}`
* **Headers**: Any valid HTTP headers (including `Stripe-Signature`, `X-HubSpot-Signature`).
* **Payload**: Raw JSON or Form Data (Max 5MB).
* **Response**: `200 OK` `{"received": true, "event_id": "evt_..."}`

## 2. Local Workstation Endpoints
* `GET /api/audit/traps`: List all active webhook traps.
* `POST /api/audit/traps`: Register a new trap token and URL.
* `POST /api/audit/diff`: Execute AST schema diff between baseline and incoming payload.
* `POST /api/audit/codegen`: Generate TypeScript, Zod, or Pydantic code.
* `POST /api/audit/replay`: Replay a payload to target URL.
* `POST /api/audit/mock`: Export standalone mock server.
* `POST /api/audit/hmac`: Verify webhook signatures.
