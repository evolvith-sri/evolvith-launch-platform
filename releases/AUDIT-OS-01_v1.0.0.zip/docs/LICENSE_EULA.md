# EVOLVITH COMMERCIAL SOFTWARE LICENSE (EULA)
## Product: AUDIT-OS-01 (Visual API Contract & Webhook QA Workstation)

1. **Grant of License**: Evolvith grants the Licensee a perpetual, non-exclusive, worldwide commercial license to install, execute, and utilize AUDIT-OS-01 across unlimited projects and clients.
2. **Seats**:
   - Tier 1: Single primary licensee / developer with unlimited personal and client projects.
   - Tier 2: Unlimited internal team seats within the purchasing organization.
3. **Redistribution**: Licensee may not redistribute, resell, or publicly host AUDIT-OS-01 as a shared multi-tenant SaaS service.
4. **Data Sovereignty**: Licensee owns 100% of all captured payload data and schema baselines stored in local SQLite databases.
