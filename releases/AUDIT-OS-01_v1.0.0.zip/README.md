# AUDIT-OS-01: Visual API Contract & Webhook QA Workstation

## Overview
`AUDIT-OS-01` is a local-first software workstation engineered to capture live webhooks, detect silent schema drift with visual AST diffs, generate type-safe models, and replay test payloads to localhost—with zero recurring subscriptions.

---

## 1. Quick Start
```bash
# 1. Install dependencies
python install.py

# 2. Run CLI commands
python src/audit_cli.py infer --file sample_event.json
python src/audit_cli.py codegen --file sample_event.json --lang zod
python src/audit_cli.py replay --url http://localhost:3000/api/webhook --file sample_event.json
```

---

## 2. Core Capabilities
* **Stateless Cloudflare Edge Ingestion**: Ingest live webhook events via public trap URLs.
* **Deterministic AST Diff Engine**: 100% mathematical structural mutation detection without AI hallucination.
* **Type Generators**: TypeScript interfaces, Zod schemas, and Python Pydantic v2 models.
* **Parameterized Replay**: Re-dispatch payloads to `localhost` with safety confirmations.
* **Standalone Mock Exporter**: Single-file zero-dependency Node.js and Python mock API servers.
* **HMAC Sandbox**: Verify Stripe, Shopify, GitHub, and custom webhook signatures offline.

---

## 3. Sovereign Storage
All payloads are stored strictly in local SQLite (`data/audit_store.db`). Zero customer payload bytes are stored permanently on central cloud servers.
