"""
AUDIT-OS-01 Standalone Installer & Health Diagnostic
"""

import sys
import os
import sqlite3

def run_diagnostics():
    print("======================================================")
    print("🚀 AUDIT-OS-01 Workstation Installation & Diagnostics")
    print("======================================================")
    
    print("\n1. Checking Python Runtime Version...")
    v = sys.version_info
    print(f"   Python {v.major}.{v.minor}.{v.micro} detected.")
    if v.major < 3 or (v.major == 3 and v.minor < 8):
        print("❌ Python 3.8+ is required.")
        sys.exit(1)
    print("   ✅ Python version compliant.")

    print("\n2. Initializing Local SQLite Sovereign Database...")
    db_dir = os.path.join(os.path.dirname(__file__), "data")
    os.makedirs(db_dir, exist_ok=True)
    db_path = os.path.join(db_dir, "audit_store.db")
    
    from src.audit_db import AuditDatabase
    db = AuditDatabase(db_path)
    db.insert_project("proj_default", "Default Workspace", "Auto-created local project")
    print(f"   ✅ SQLite database initialized at {db_path}")

    print("\n3. Verifying AST Schema Engine...")
    from src.audit_os_core import AstSchemaEngine, CodeGenerator
    test_payload = {"id": "evt_123", "amount": 5000, "customer": {"email": "dev@company.com"}}
    schema = AstSchemaEngine.infer_schema(test_payload)
    ts_code = CodeGenerator.generate_typescript(schema, "TestEvent")
    assert "interface TestEvent" in ts_code
    print("   ✅ AST Schema Engine and Code Generator verified.")

    print("\n======================================================")
    print("🎉 AUDIT-OS-01 is fully operational and ready for use!")
    print("======================================================")

if __name__ == "__main__":
    run_diagnostics()
