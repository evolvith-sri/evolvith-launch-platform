# Troubleshooting Guide — Autonomous Revenue Engine & Deal Velocity OS

Run diagnostic check: `python -m src.cli health`.
