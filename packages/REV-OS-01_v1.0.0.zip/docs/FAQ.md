# FAQ — Autonomous Revenue Engine & Deal Velocity OS

Q: Is internet connection required?
A: No, executes locally with 100% data privacy.
