# REV-OS-01 — Quarterly Revenue Capacity Planning Worksheet

> **Reference Implementation v1.0.0 | Repository D Product Factory**

---

## 1. Quota & Capacity Inputs
- Target Quarterly ARR Goal ($): ____________________
- Total Account Executives (FTEs): ____________________
- Quota Target Per AE ($): ____________________
- Historical Win Rate (%): ____________________
- Average Deal Size ($): ____________________
- Average Sales Cycle (Days): ____________________

## 2. Required Pipeline Calculation
- Required Closed Deals = Target ARR Goal / Average Deal Size
- Required Qualified Deals = Required Closed Deals / (Win Rate / 100)
- Required Active Pipeline ($) = Required Qualified Deals * Average Deal Size
- Minimum Pipeline Coverage Ratio = Required Active Pipeline / Target ARR Goal (Target: ≥ 3.5x)

---

*REV-OS-01 Reference Implementation — Planning Worksheets.*
