"""
REV-OS-01 Deal Velocity Scoring Engine (DVS-100)
Reference Implementation v1.0.0 | Repository D Product Factory
"""

from typing import Dict, Any

class DealScoringEngine:
    """Algorithmic Deal Velocity Scoring Engine implementing DVS-100 specs."""

    @staticmethod
    def calculate_score(deal: Dict[str, Any]) -> Dict[str, Any]:
        arr = deal.get("arr_usd", 10000)
        stage_days = deal.get("stage_duration_days", 10)
        contacts = deal.get("contacts_count", 1)
        has_sponsor = deal.get("has_sponsor", False)

        # Weighted calculation
        duration_penalty = max(0, stage_days - 14) * 2.0
        contacts_bonus = min(30.0, contacts * 10.0)
        sponsor_bonus = 25.0 if has_sponsor else 0.0

        raw_score = 65.0 - duration_penalty + contacts_bonus + sponsor_bonus
        final_score = max(0.0, min(100.0, round(raw_score, 1)))

        risk_level = "GREEN" if final_score >= 80.0 else ("YELLOW" if final_score >= 50.0 else "RED")

        return {
            "deal_id": deal.get("id", "UNKNOWN"),
            "arr_usd": arr,
            "dvs_score": final_score,
            "risk_level": risk_level,
            "recommendation": "Accelerate proposal synthesis" if final_score >= 80 else "Enforce manager intervention"
        }
