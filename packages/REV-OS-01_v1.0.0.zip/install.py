import sys
from pathlib import Path
from factory_core.modules.installer import QuickstartInstaller

def main():
    installer = QuickstartInstaller(Path(__file__).parent, "Autonomous Revenue Engine & Deal Velocity OS")
    success = installer.run_installation()
    if not success:
        sys.exit(1)

if __name__ == "__main__":
    main()
