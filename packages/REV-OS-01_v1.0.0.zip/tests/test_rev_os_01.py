import sys
from pathlib import Path
prod_dir = Path(__file__).parent.parent
sys.path.insert(0, str(prod_dir))
for k in list(sys.modules.keys()):
    if k == "src" or k.startswith("src."):
        del sys.modules[k]
import pytest
from src.engine import OperatingSystemEngine

def test_engine_execution():
    engine = OperatingSystemEngine()
    res = engine.execute_workflow({})
    assert res["status"] == "SUCCESS"
    assert res["product_id"] == "REV-OS-01"

def test_health_check():
    engine = OperatingSystemEngine()
    status = engine.health.get_health_status()
    assert status["status"] == "HEALTHY"
