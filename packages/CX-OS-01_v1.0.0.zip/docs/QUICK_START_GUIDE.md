# Quick Start Guide — Sub-Second Autonomous Support Resolution OS

Deploy in under 5 minutes:
```bash
python install.py
python -m src.cli run
```
