# Troubleshooting Guide — Sub-Second Autonomous Support Resolution OS

Run diagnostic check: `python -m src.cli health`.
