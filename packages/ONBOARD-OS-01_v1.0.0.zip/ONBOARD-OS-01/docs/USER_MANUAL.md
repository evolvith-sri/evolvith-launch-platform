# ONBOARD-OS-01 — USER MANUAL & OPERATOR GUIDE

> **Product ID**: ONBOARD-OS-01  
> **Audience**: Customer Success Managers, Onboarding Leads, Implementation Specialists  

---

## 1. DAILY & WEEKLY OPERATOR WORKFLOW

1. **Step 1 — Morning Health Diagnostics**:
   ```bash
   python src/cli.py health
   ```
   Confirm system diagnostics return `HEALTHY`.

2. **Step 2 — Generate Onboarding Summary Table**:
   ```bash
   python src/cli.py summary
   ```
   Review the `OPERATIONAL BOTTLENECK INVENTORY` and `ACTIVATION HEALTH BREAKDOWN`.

3. **Step 3 — Actioning Bottlenecks by Priority**:
   - Focus immediately on Tier-3 Executive accounts (Enterprise accounts stalled or hard-blocked).
   - Resolve Tier-2 Technical Stalls with Onboarding Leads (Data Migration / Configuration roadblocks).
   - Address Tier-1 CSM Alerts (re-engage accounts approaching 5 days of inactivity).

4. **Step 4 — Update Milestone State**:
   Log milestone gate transitions and customer blocker resolutions in your central records.

---

*ONBOARD-OS-01 User Manual v1.0.0 — Authoritative.*
