# ONBOARD-OS-01 — INTERFACE SPECIFICATION & INTEGRATION BOUNDARY

> **Product ID**: ONBOARD-OS-01  
> **Document Type**: Technical Interface Specification / Integration Contract  
> **Status**: Interface Contract Specification (Self-Hosted / Local Execution)  
> **Note**: This document defines the payload contracts for connecting internal CRM, project management, and customer databases to ONBOARD-OS-01. Live third-party API adapters are executed within customer infrastructure.  

---

## 1. INGESTION DATA CONTRACT (JSON SCHEMA)

### Inbound Accounts Array Payload: `POST /api/v1/onboarding/ingest`
```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "title": "OnboardOSInboundAccounts",
  "type": "object",
  "required": ["accounts"],
  "properties": {
    "as_of_date": {
      "type": "string",
      "format": "date",
      "description": "Optional audit reference date (YYYY-MM-DD). Defaults to execution date."
    },
    "stall_threshold_days": {
      "type": "integer",
      "default": 5,
      "description": "Configurable inactivity stall threshold in days."
    },
    "custom_milestones": {
      "type": "array",
      "description": "Optional custom milestone sequence overriding default 5 gates.",
      "items": {
        "type": "object",
        "required": ["id", "name", "sequence", "target_sla_days"],
        "properties": {
          "id": { "type": "string" },
          "name": { "type": "string" },
          "sequence": { "type": "integer" },
          "target_sla_days": { "type": "integer" },
          "owner_role": { "type": "string" }
        }
      }
    },
    "accounts": {
      "type": "array",
      "items": {
        "type": "object",
        "required": ["account_id", "account_name", "contract_start_date", "current_gate"],
        "properties": {
          "account_id": { "type": "string" },
          "account_name": { "type": "string" },
          "plan_tier": { "type": "string", "default": "STANDARD" },
          "contract_value": { "type": "number", "minimum": 0, "default": 0 },
          "currency": { "type": "string", "default": "USD" },
          "assigned_csm": { "type": "string", "default": "Unassigned" },
          "current_gate": { "type": "string" },
          "contract_start_date": { "type": "string", "format": "date" },
          "gate_entered_at": { "type": "string", "format": "date" },
          "last_activity_at": { "type": "string", "format": "date" },
          "target_go_live_date": { "type": "string", "format": "date" },
          "actual_go_live_date": { "type": "string", "format": "date" },
          "is_blocked": { "type": "boolean", "default": false },
          "blocker_reason": { "type": "string", "default": "" }
        }
      }
    }
  }
}
```

---

## 2. OUTBOUND AUDIT EXECUTION CONTRACT

### Response Payload Schema: `200 OK`
```json
{
  "status": "SUCCESS",
  "product_id": "ONBOARD-OS-01",
  "product_name": "Customer Onboarding & Activation OS",
  "version": "1.0.0",
  "summary": {
    "as_of_date": "2026-08-17",
    "stall_threshold_days": 5,
    "total_accounts_audited": 10,
    "active_onboarding_count": 7,
    "completed_activation_count": 2,
    "stalled_accounts_count": 2,
    "stalled_onboarding_ratio_percentage": 28.6,
    "blocked_accounts_count": 1,
    "unassigned_csm_count": 1,
    "overdue_target_count": 1,
    "average_ttfv_completed_days": 18.5,
    "average_elapsed_inflight_days": 16.4,
    "action_queue_count": 4,
    "health_distribution_count": {
      "HEALTHY": 4,
      "AT_RISK": 2,
      "CRITICAL": 1,
      "ACTIVATED": 2,
      "CANCELLED": 1
    }
  },
  "priority_action_queue": [
    {
      "account_id": "ONB-2026-001",
      "account_name": "Apex Global Logistics",
      "contract_value": 48000.00,
      "plan_tier": "ENTERPRISE",
      "current_gate": "DATA_IMPORT",
      "days_in_gate": 20,
      "days_inactive": 16,
      "is_blocked": true,
      "blocker_reason": "Customer legacy schema CSV syntax mismatch",
      "activation_health_score": 15.0,
      "activation_health_status": "CRITICAL",
      "recommended_action": "Executive Escalation: VP Customer Success intervention required for blocker: 'Customer legacy schema CSV syntax mismatch'",
      "escalation_level": "TIER_3_EXECUTIVE_INTERVENTION"
    }
  ],
  "metrics": {
    "status": "HEALTHY",
    "product_id": "ONBOARD-OS-01",
    "version": "1.0.0"
  }
}
```

---

## 3. WEBHOOK EVENT CONTRACTS (FUTURE INTEGRATION BOUNDARIES)

1. **`onboarding.stall.detected`**: Dispatched when an in-flight account exceeds the configured inactivity threshold.
2. **`onboarding.blocker.logged`**: Dispatched when `is_blocked=true` is submitted.
3. **`onboarding.activation.completed`**: Dispatched upon successful milestone sign-off into `ACTIVATED`.

---

*ONBOARD-OS-01 API Specification v1.0.0 — Authoritative.*
