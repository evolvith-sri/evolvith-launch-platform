"""
ONBOARD-OS-01: Command-Line Interface (CLI)
Customer Onboarding & Activation OS
"""

import sys
import json
import argparse
from pathlib import Path
from typing import Optional

# Ensure package path is resolvable
current_dir = Path(__file__).resolve().parent
product_root = current_dir.parent
if str(product_root) not in sys.path:
    sys.path.insert(0, str(product_root))

from src.engine import OperatingSystemEngine


def format_currency(val: float, currency: str = "USD") -> str:
    return f"{currency} {val:,.2f}"


def print_summary_table(result: dict):
    if result.get("status") != "SUCCESS":
        print(f"[ERROR] Workflow failed: {result.get('error')}")
        return

    summary = result["summary"]
    print("\n" + "=" * 82)
    print("  ONBOARD-OS-01: CUSTOMER ONBOARDING & ACTIVATION AUDIT SUMMARY")
    print("=" * 82)
    print(f"  Audit Reference Date         : {summary['as_of_date']}")
    print(f"  Total Accounts Audited       : {summary['total_accounts_audited']}")
    print(f"  Active In-Flight Onboarding  : {summary['active_onboarding_count']} accounts")
    print(f"  Completed / Live Activations : {summary['completed_activation_count']} accounts")
    print(f"  Average TTFV (Completed)     : {summary['average_ttfv_completed_days']} days from contract start")
    print(f"  Average In-Flight Duration   : {summary['average_elapsed_inflight_days']} days elapsed")
    print("-" * 82)
    print("  OPERATIONAL BOTTLENECK INVENTORY:")
    print(f"    - Stalled Accounts (> {summary['stall_threshold_days']}d) : {summary['stalled_accounts_count']} accounts ({summary['stalled_onboarding_ratio_percentage']}%)")
    print(f"    - Hard Blocked Accounts    : {summary['blocked_accounts_count']} accounts")
    print(f"    - Unassigned CSMs          : {summary['unassigned_csm_count']} accounts")
    print(f"    - Overdue Target Go-Lives  : {summary['overdue_target_count']} accounts")
    print("-" * 82)
    print("  MILESTONE DISTRIBUTION:")
    for gate, count in summary["milestone_distribution_count"].items():
        if count > 0:
            print(f"    - {gate:<26}: {count:>2} accounts")
    print("-" * 82)
    print("  ACTIVATION HEALTH BREAKDOWN:")
    for status, count in summary["health_distribution_count"].items():
        print(f"    - {status:<15}: {count:>2} accounts")
    print("-" * 82)

    queue = result.get("priority_action_queue", [])
    print(f"  PRIORITY ACTION QUEUE (Top {min(5, len(queue))} of {len(queue)} items requiring operational triage):")
    if not queue:
        print("    [OK] No onboarding defects detected. All customer journeys on schedule.")
    else:
        for idx, item in enumerate(queue[:5], 1):
            print(f"    {idx}. [{item['activation_health_status']}] {item['account_id']} | {item['account_name']} ({item['current_gate']})")
            print(f"       Value: {format_currency(item['contract_value'], item['currency'])} | CSM: {item['assigned_csm']} | Inactive: {item['days_inactive']}d | In Gate: {item['days_in_gate']}d")
            print(f"       Action: {item['recommended_action']}")
            print(f"       Escalation: {item['escalation_level']}")
    print("=" * 82 + "\n")


def main():
    parser = argparse.ArgumentParser(
        description="ONBOARD-OS-01: Customer Onboarding & Activation OS CLI"
    )
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # Command: health
    subparsers.add_parser("health", help="Execute system health & diagnostics check")

    # Command: run
    run_parser = subparsers.add_parser("run", help="Execute onboarding audit on customer dataset")
    run_parser.add_argument(
        "--input", "-i",
        type=str,
        default=str(product_root / "samples" / "synthetic_onboarding.json"),
        help="Path to JSON file containing accounts payload"
    )
    run_parser.add_argument(
        "--output", "-o",
        type=str,
        help="Optional path to write JSON output result"
    )
    run_parser.add_argument(
        "--as-of-date", "-d",
        type=str,
        help="Optional audit reference date (YYYY-MM-DD)"
    )
    run_parser.add_argument(
        "--stall-threshold", "-t",
        type=int,
        default=5,
        help="Configurable stall inactivity threshold in days (default: 5)"
    )

    # Command: summary
    summary_parser = subparsers.add_parser("summary", help="Run audit and print human-readable operational table")
    summary_parser.add_argument(
        "--input", "-i",
        type=str,
        default=str(product_root / "samples" / "synthetic_onboarding.json"),
        help="Path to JSON file containing accounts payload"
    )
    summary_parser.add_argument(
        "--as-of-date", "-d",
        type=str,
        help="Optional audit reference date (YYYY-MM-DD)"
    )
    summary_parser.add_argument(
        "--stall-threshold", "-t",
        type=int,
        default=5,
        help="Configurable stall inactivity threshold in days (default: 5)"
    )

    args = parser.parse_args()
    engine = OperatingSystemEngine()

    if args.command == "health":
        health_status = engine.health.get_health_status()
        print(json.dumps(health_status, indent=2))
        return

    if args.command in ["run", "summary"]:
        input_path = Path(args.input)
        if not input_path.exists():
            print(f"[ERROR] Input dataset file not found: '{input_path}'", file=sys.stderr)
            sys.exit(1)

        try:
            with open(input_path, "r", encoding="utf-8") as f:
                data = json.load(f)
        except Exception as e:
            print(f"[ERROR] Failed to read JSON from '{input_path}': {e}", file=sys.stderr)
            sys.exit(1)

        payload = {"accounts": data if isinstance(data, list) else data.get("accounts", [])}
        if args.as_of_date:
            payload["as_of_date"] = args.as_of_date
        if args.stall_threshold:
            payload["stall_threshold_days"] = args.stall_threshold

        res = engine.execute_workflow(payload)

        if args.command == "summary":
            print_summary_table(res)
        else:
            json_output = json.dumps(res, indent=2)
            if args.output:
                output_path = Path(args.output)
                output_path.parent.mkdir(parents=True, exist_ok=True)
                with open(output_path, "w", encoding="utf-8") as f:
                    f.write(json_output)
                print(f"[SUCCESS] Workflow executed. Result written to '{output_path}'")
            else:
                print(json_output)

        if res.get("status") != "SUCCESS":
            sys.exit(1)
        return

    parser.print_help()


if __name__ == "__main__":
    main()
