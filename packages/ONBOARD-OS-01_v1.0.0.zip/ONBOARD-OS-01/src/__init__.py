"""
ONBOARD-OS-01: Customer Onboarding & Activation OS
Evolvith Wave 2 Focused Operating System
"""

from .engine import OperatingSystemEngine

__version__ = "1.0.0"
__all__ = ["OperatingSystemEngine"]
