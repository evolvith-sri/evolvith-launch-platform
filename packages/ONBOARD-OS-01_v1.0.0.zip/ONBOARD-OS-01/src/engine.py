"""
ONBOARD-OS-01: Execution Engine
Customer Onboarding & Activation OS
"""

import sys
import os
from datetime import datetime, date
from typing import List, Dict, Any, Optional

try:
    from factory_core.modules.health import HealthDiagnosticsHandler
except ImportError:
    class HealthDiagnosticsHandler:
        def __init__(self, product_id: str):
            self.product_id = product_id
        def get_health_status(self) -> dict:
            return {
                "status": "HEALTHY",
                "product_id": self.product_id,
                "version": "1.0.0",
                "uptime_seconds": 0.0,
                "python_version": sys.version.split()[0],
                "platform": sys.platform,
                "genome_compliance": "GENOME_ALPHA_V1",
                "sla_guarantee_ms": 500
            }


class OperatingSystemEngine:
    """Core workflow execution engine for ONBOARD-OS-01 Customer Onboarding & Activation OS."""

    # Default 5-Gate Onboarding Lifecycle Specification
    DEFAULT_MILESTONES = [
        {"id": "KICKOFF", "name": "Kickoff & Alignment", "sequence": 1, "target_sla_days": 5, "owner_role": "CSM"},
        {"id": "CONFIGURATION", "name": "Workspace & Integration Config", "sequence": 2, "target_sla_days": 7, "owner_role": "Implementation Lead"},
        {"id": "DATA_IMPORT", "name": "Data Migration & Mapping", "sequence": 3, "target_sla_days": 7, "owner_role": "Technical Specialist"},
        {"id": "TRAINING", "name": "Stakeholder Training & Enablement", "sequence": 4, "target_sla_days": 5, "owner_role": "CSM / Trainer"},
        {"id": "GO_LIVE", "name": "Production Launch & Sign-Off", "sequence": 5, "target_sla_days": 3, "owner_role": "Onboarding Lead"}
    ]

    VALID_TERMINAL_GATES = {"ACTIVATED", "COMPLETED", "CANCELLED", "CHURNED_IN_ONBOARDING"}
    REQUIRED_FIELDS = {"account_id", "account_name", "contract_start_date", "current_gate"}
    DEFAULT_STALL_THRESHOLD_DAYS = 5

    def __init__(self):
        self.product_id = "ONBOARD-OS-01"
        self.product_name = "Customer Onboarding & Activation OS"
        self.version = "1.0.0"
        self.health = HealthDiagnosticsHandler(self.product_id)

    def get_milestone_map(self, custom_milestones: Optional[List[Dict[str, Any]]] = None) -> Dict[str, Dict[str, Any]]:
        """Builds an indexed dictionary of active milestones from defaults or custom configuration."""
        raw_list = custom_milestones if (custom_milestones and isinstance(custom_milestones, list)) else self.DEFAULT_MILESTONES
        milestone_map = {}
        for idx, m in enumerate(raw_list, 1):
            mid = str(m.get("id", f"GATE_{idx}")).strip().upper()
            milestone_map[mid] = {
                "id": mid,
                "name": str(m.get("name", mid)).strip(),
                "sequence": int(m.get("sequence", idx)),
                "target_sla_days": int(m.get("target_sla_days", 7)),
                "owner_role": str(m.get("owner_role", "CSM")).strip()
            }
        return milestone_map

    def validate_account(self, acct: Dict[str, Any], seen_ids: set, milestone_map: Dict[str, Dict[str, Any]]) -> Dict[str, Any]:
        """Validates a single onboarding account record and raises ValueError on invalid schema."""
        if not isinstance(acct, dict):
            raise ValueError(f"Malformed account record: expected dict, received {type(acct).__name__}")

        # Validate required fields
        for field in self.REQUIRED_FIELDS:
            if field not in acct or acct[field] is None or str(acct[field]).strip() == "":
                raise ValueError(f"Missing required field: '{field}' in account: {acct}")

        account_id = str(acct["account_id"]).strip()
        if account_id in seen_ids:
            raise ValueError(f"Duplicate account identifier detected: '{account_id}'")
        seen_ids.add(account_id)

        # Validate contract value / ARR
        try:
            arr = float(acct.get("contract_value", acct.get("arr", 0.0)))
            if arr < 0:
                raise ValueError(f"Contract value cannot be negative: {arr} in account '{account_id}'")
        except (ValueError, TypeError) as e:
            raise ValueError(f"Invalid contract value in account '{account_id}': {e}")

        # Validate current gate
        current_gate = str(acct["current_gate"]).strip().upper()
        valid_gate_ids = set(milestone_map.keys()) | self.VALID_TERMINAL_GATES
        if current_gate not in valid_gate_ids:
            raise ValueError(f"Invalid current_gate '{current_gate}' in account '{account_id}'. Valid gates: {sorted(list(valid_gate_ids))}")

        # Helper to parse date fields
        def parse_date(field_name: str, is_required: bool = False) -> Optional[date]:
            val = acct.get(field_name)
            if val is not None and str(val).strip() != "":
                try:
                    return datetime.strptime(str(val).strip(), "%Y-%m-%d").date()
                except ValueError:
                    raise ValueError(f"Invalid date format '{val}' for field '{field_name}' in account '{account_id}'. Expected 'YYYY-MM-DD'.")
            elif is_required:
                raise ValueError(f"Missing required date field '{field_name}' in account '{account_id}'")
            return None

        contract_start_date = parse_date("contract_start_date", is_required=True)
        gate_entered_at = parse_date("gate_entered_at") or contract_start_date
        last_activity_at = parse_date("last_activity_at") or gate_entered_at
        target_go_live_date = parse_date("target_go_live_date")
        actual_go_live_date = parse_date("actual_go_live_date")

        assigned_csm = str(acct.get("assigned_csm", acct.get("owner", "Unassigned"))).strip()
        is_blocked = bool(acct.get("is_blocked", False))
        blocker_reason = str(acct.get("blocker_reason", "")).strip()

        return {
            "account_id": account_id,
            "account_name": str(acct["account_name"]).strip(),
            "plan_tier": str(acct.get("plan_tier", "STANDARD")).strip().upper(),
            "contract_value": arr,
            "currency": str(acct.get("currency", "USD")).strip().upper(),
            "assigned_csm": assigned_csm,
            "current_gate": current_gate,
            "contract_start_date": contract_start_date,
            "gate_entered_at": gate_entered_at,
            "last_activity_at": last_activity_at,
            "target_go_live_date": target_go_live_date,
            "actual_go_live_date": actual_go_live_date,
            "is_blocked": is_blocked,
            "blocker_reason": blocker_reason
        }

    def process_account(
        self,
        acct: Dict[str, Any],
        as_of_date: date,
        milestone_map: Dict[str, Dict[str, Any]],
        stall_threshold: int
    ) -> Dict[str, Any]:
        """Evaluates onboarding milestone latency, TTFV, stall triggers, activation health, and RACI escalations."""
        gate = acct["current_gate"]
        arr = acct["contract_value"]
        csm = acct["assigned_csm"]
        is_blocked = acct["is_blocked"]
        blocker_reason = acct["blocker_reason"]
        start_date: date = acct["contract_start_date"]
        gate_date: date = acct["gate_entered_at"]
        activity_date: date = acct["last_activity_at"]
        target_live: Optional[date] = acct["target_go_live_date"]
        actual_live: Optional[date] = acct["actual_go_live_date"]

        # Terminal state handling (Completed / Activated)
        if gate in ["ACTIVATED", "COMPLETED"]:
            ttfv_days = (actual_live - start_date).days if actual_live else (gate_date - start_date).days
            return {
                **acct,
                "contract_start_date": start_date.isoformat(),
                "gate_entered_at": gate_date.isoformat(),
                "last_activity_at": activity_date.isoformat(),
                "target_go_live_date": target_live.isoformat() if target_live else None,
                "actual_go_live_date": actual_live.isoformat() if actual_live else gate_date.isoformat(),
                "days_in_gate": 0,
                "days_inactive": 0,
                "elapsed_onboarding_days": ttfv_days,
                "ttfv_days": max(0, ttfv_days),
                "is_stalled": False,
                "is_unassigned_csm": False,
                "is_overdue_target": False,
                "activation_health_score": 100.0,
                "activation_health_status": "ACTIVATED",
                "recommended_action": "Onboarding Complete — Handed over to Ongoing Customer Success",
                "escalation_level": "NONE",
                "action_required": False
            }

        # Terminal state handling (Cancelled / Churned)
        if gate in ["CANCELLED", "CHURNED_IN_ONBOARDING"]:
            elapsed = (as_of_date - start_date).days
            return {
                **acct,
                "contract_start_date": start_date.isoformat(),
                "gate_entered_at": gate_date.isoformat(),
                "last_activity_at": activity_date.isoformat(),
                "target_go_live_date": target_live.isoformat() if target_live else None,
                "actual_go_live_date": None,
                "days_in_gate": 0,
                "days_inactive": (as_of_date - activity_date).days,
                "elapsed_onboarding_days": elapsed,
                "ttfv_days": None,
                "is_stalled": False,
                "is_unassigned_csm": False,
                "is_overdue_target": False,
                "activation_health_score": 0.0,
                "activation_health_status": "CANCELLED",
                "recommended_action": "Account Cancelled During Onboarding — Post-Mortem Required",
                "escalation_level": "NONE",
                "action_required": False
            }

        # In-Flight Operational Calculations
        days_in_gate = max(0, (as_of_date - gate_date).days)
        days_inactive = max(0, (as_of_date - activity_date).days)
        elapsed_days = max(0, (as_of_date - start_date).days)

        current_milestone_spec = milestone_map.get(gate, {"target_sla_days": 7, "sequence": 1})
        gate_target_sla = current_milestone_spec.get("target_sla_days", 7)
        gate_seq = current_milestone_spec.get("sequence", 1)
        total_milestones = len(milestone_map)

        # Stall condition: inactivity exceeds stall_threshold OR days in gate exceeds 2x target SLA
        is_stalled = (days_inactive > stall_threshold) or (days_in_gate > (gate_target_sla * 2))
        is_unassigned_csm = (not csm or csm.lower() in ["unassigned", "none", ""])
        is_overdue_target = (target_live is not None and as_of_date > target_live)

        # Activation Health Score Calculation (0 - 100)
        # Base healthy score starts at 85.0 + milestone progress weight up to 15.0
        progress_weight = (gate_seq / max(1, total_milestones)) * 15.0
        health_score = 85.0 + progress_weight

        # Apply operational penalties
        if is_stalled:
            health_score -= 25.0
        if is_blocked:
            health_score -= 30.0
        if is_unassigned_csm:
            health_score -= 15.0
        if is_overdue_target:
            health_score -= 15.0
        if days_in_gate > gate_target_sla:
            health_score -= min(15.0, (days_in_gate - gate_target_sla) * 2.0)

        health_score = round(max(5.0, min(100.0, health_score)), 1)

        # Activation Health Status Tier
        if health_score >= 75.0:
            health_status = "HEALTHY"
        elif health_score >= 45.0:
            health_status = "AT_RISK"
        else:
            health_status = "CRITICAL"

        # 4-Tier RACI Escalation Logic
        action_required = (is_stalled or is_blocked or is_unassigned_csm or is_overdue_target or health_status in ["AT_RISK", "CRITICAL"])

        if (arr >= 25000.0 and (is_stalled or is_blocked)) or elapsed_days > 45 or (is_blocked and days_in_gate > 10):
            escalation_level = "TIER_3_EXECUTIVE_INTERVENTION"
            recommended_action = f"Executive Escalation: VP Customer Success intervention required for blocker: '{blocker_reason or 'Critical Onboarding Stall'}'"
        elif is_stalled or is_blocked or is_overdue_target or health_status == "CRITICAL":
            escalation_level = "TIER_2_LEAD_ESCALATION"
            recommended_action = f"Onboarding Lead Triage: Resolve gate '{gate}' blocker ('{blocker_reason or 'Inactivity breach'}') and schedule customer unblock call"
        elif is_unassigned_csm or days_inactive >= 3 or (days_in_gate > gate_target_sla):
            escalation_level = "TIER_1_CSM_ALERT"
            if is_unassigned_csm:
                recommended_action = "Assign Dedicated Onboarding CSM / Implementation Lead immediately"
            else:
                recommended_action = f"CSM Outreach: Re-engage customer contact on '{gate}' deliverables"
        else:
            escalation_level = "NONE"
            recommended_action = f"Onboarding On Track in '{gate}' (Day {days_in_gate} of {gate_target_sla} SLA)"

        # Estimated TTFV Projection for in-flight account
        remaining_gates = max(0, total_milestones - gate_seq + 1)
        projected_ttfv = elapsed_days + (remaining_gates * 5)

        return {
            **acct,
            "contract_start_date": start_date.isoformat(),
            "gate_entered_at": gate_date.isoformat(),
            "last_activity_at": activity_date.isoformat(),
            "target_go_live_date": target_live.isoformat() if target_live else None,
            "actual_go_live_date": None,
            "days_in_gate": days_in_gate,
            "days_inactive": days_inactive,
            "elapsed_onboarding_days": elapsed_days,
            "projected_ttfv_days": projected_ttfv,
            "ttfv_days": None,
            "is_stalled": is_stalled,
            "is_unassigned_csm": is_unassigned_csm,
            "is_overdue_target": is_overdue_target,
            "activation_health_score": health_score,
            "activation_health_status": health_status,
            "recommended_action": recommended_action,
            "escalation_level": escalation_level,
            "action_required": action_required
        }

    def execute_workflow(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """
        Executes end-to-end customer onboarding and activation audit workflow.
        Accepts: {"accounts": List[dict], "as_of_date": Optional[str], "custom_milestones": Optional[List[dict]], "stall_threshold_days": Optional[int]}
        Returns: Structured operational audit with onboarding metrics, stall queues, TTFV analytics, and RACI escalations.
        """
        if not isinstance(payload, dict):
            return {
                "status": "ERROR",
                "product_id": self.product_id,
                "error": f"Invalid payload: expected dict, received {type(payload).__name__}",
                "metrics": self.health.get_health_status()
            }

        raw_accounts = payload.get("accounts", [])
        if not isinstance(raw_accounts, list):
            return {
                "status": "ERROR",
                "product_id": self.product_id,
                "error": "Field 'accounts' must be a list",
                "metrics": self.health.get_health_status()
            }

        # Parse reference date
        as_of_str = payload.get("as_of_date")
        if as_of_str:
            try:
                as_of_date = datetime.strptime(str(as_of_str).strip(), "%Y-%m-%d").date()
            except ValueError:
                return {
                    "status": "ERROR",
                    "product_id": self.product_id,
                    "error": f"Invalid as_of_date format '{as_of_str}'. Expected 'YYYY-MM-DD'.",
                    "metrics": self.health.get_health_status()
                }
        else:
            as_of_date = date.today()

        # Parse configuration overrides
        custom_milestones = payload.get("custom_milestones")
        milestone_map = self.get_milestone_map(custom_milestones)
        
        stall_threshold = int(payload.get("stall_threshold_days", self.DEFAULT_STALL_THRESHOLD_DAYS))

        # Validate and process all accounts
        seen_ids = set()
        validated_accounts = []
        try:
            for acct in raw_accounts:
                cleaned = self.validate_account(acct, seen_ids, milestone_map)
                processed = self.process_account(cleaned, as_of_date, milestone_map, stall_threshold)
                validated_accounts.append(processed)
        except ValueError as e:
            return {
                "status": "VALIDATION_FAILED",
                "product_id": self.product_id,
                "error": str(e),
                "metrics": self.health.get_health_status()
            }

        # Filter actionable items sorted by contract_value descending, then health score ascending
        action_queue = [acct for acct in validated_accounts if acct["action_required"]]
        action_queue.sort(key=lambda x: (x["contract_value"], 100.0 - x["activation_health_score"]), reverse=True)

        # Aggregate Metrics
        total_audited = len(validated_accounts)
        completed_accounts = [a for a in validated_accounts if a["activation_health_status"] == "ACTIVATED"]
        inflight_accounts = [a for a in validated_accounts if a["activation_health_status"] in ["HEALTHY", "AT_RISK", "CRITICAL"]]
        stalled_accounts = [a for a in inflight_accounts if a["is_stalled"]]
        blocked_accounts = [a for a in inflight_accounts if a["is_blocked"]]
        unassigned_csm_accounts = [a for a in inflight_accounts if a["is_unassigned_csm"]]
        overdue_target_accounts = [a for a in inflight_accounts if a["is_overdue_target"]]

        # TTFV Metrics
        if completed_accounts:
            avg_ttfv_days = round(sum(a["ttfv_days"] for a in completed_accounts if a["ttfv_days"] is not None) / len(completed_accounts), 1)
        else:
            avg_ttfv_days = 0.0

        if inflight_accounts:
            avg_elapsed_inflight_days = round(sum(a["elapsed_onboarding_days"] for a in inflight_accounts) / len(inflight_accounts), 1)
        else:
            avg_elapsed_inflight_days = 0.0

        # Health Distribution
        health_counts = {"HEALTHY": 0, "AT_RISK": 0, "CRITICAL": 0, "ACTIVATED": 0, "CANCELLED": 0}
        for a in validated_accounts:
            st = a["activation_health_status"]
            health_counts[st] = health_counts.get(st, 0) + 1

        # Milestone Distribution
        gate_counts = {g: 0 for g in milestone_map.keys()}
        for t in self.VALID_TERMINAL_GATES:
            gate_counts[t] = 0
        for a in validated_accounts:
            g = a["current_gate"]
            gate_counts[g] = gate_counts.get(g, 0) + 1

        operational_summary = {
            "as_of_date": as_of_date.isoformat(),
            "stall_threshold_days": stall_threshold,
            "total_accounts_audited": total_audited,
            "active_onboarding_count": len(inflight_accounts),
            "completed_activation_count": len(completed_accounts),
            "stalled_accounts_count": len(stalled_accounts),
            "stalled_onboarding_ratio_percentage": round((len(stalled_accounts) / len(inflight_accounts) * 100) if inflight_accounts else 0.0, 1),
            "blocked_accounts_count": len(blocked_accounts),
            "unassigned_csm_count": len(unassigned_csm_accounts),
            "overdue_target_count": len(overdue_target_accounts),
            "average_ttfv_completed_days": avg_ttfv_days,
            "average_elapsed_inflight_days": avg_elapsed_inflight_days,
            "action_queue_count": len(action_queue),
            "health_distribution_count": health_counts,
            "milestone_distribution_count": gate_counts
        }

        return {
            "status": "SUCCESS",
            "product_id": self.product_id,
            "product_name": self.product_name,
            "version": self.version,
            "summary": operational_summary,
            "priority_action_queue": action_queue,
            "accounts": validated_accounts,
            "milestones_configured": list(milestone_map.values()),
            "metrics": self.health.get_health_status()
        }
