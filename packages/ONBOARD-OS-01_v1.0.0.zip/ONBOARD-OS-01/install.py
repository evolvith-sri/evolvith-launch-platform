#!/usr/bin/env python3
"""
ONBOARD-OS-01: Automated Quickstart Installer
Customer Onboarding & Activation OS
"""

import sys
import os
import shutil
from pathlib import Path

def main():
    product_dir = Path(__file__).resolve().parent
    product_name = "ONBOARD-OS-01 Customer Onboarding & Activation OS"

    print(f"=== Installing {product_name} (Evolvith Wave 2 Release 1.0.0) ===")
    print("1. Verifying Environment & Python Version...")
    if sys.version_info < (3, 9):
        print(f"  [ERROR] Python 3.9+ is required. Detected: {sys.version.split()[0]}", file=sys.stderr)
        sys.exit(1)
    print(f"  [OK] Python runtime verified: {sys.version.split()[0]}")

    print("2. Generating Default Configuration (.env)...")
    env_target = product_dir / ".env"
    if not env_target.exists():
        default_env = (
            "# ONBOARD-OS-01 Configuration\n"
            "PRODUCT_ID=ONBOARD-OS-01\n"
            "ENVIRONMENT=production\n"
            "DEFAULT_CURRENCY=USD\n"
            "DEFAULT_STALL_THRESHOLD_DAYS=5\n"
            "DEFAULT_TARGET_TTFV_DAYS=30\n"
            "LOG_LEVEL=INFO\n"
        )
        with open(env_target, "w", encoding="utf-8") as f:
            f.write(default_env)
        print("  [OK] Generated default .env file.")
    else:
        print("  [OK] Existing .env file validated.")

    print("3. Validating Directory Structure & Core Modules...")
    required_dirs = ["docs", "samples", "workflows", "templates"]
    for d in required_dirs:
        dir_path = product_dir / d
        if not dir_path.exists():
            dir_path.mkdir(parents=True, exist_ok=True)
            print(f"  [OK] Created directory: '{d}'")
        else:
            print(f"  [OK] Verified directory: '{d}'")

    print("4. Verifying Core Executable Artifacts...")
    required_files = [
        "src/engine.py",
        "src/cli.py",
        "src/__init__.py",
        "blueprint.json",
        "SOP_MANUAL.md",
        "README.md",
        "LICENSE_EULA.md"
    ]
    for rf in required_files:
        fp = product_dir / rf
        if not fp.exists():
            print(f"  [ERROR] Missing required artifact: '{rf}'", file=sys.stderr)
            sys.exit(1)
        print(f"  [OK] Verified artifact: '{rf}'")

    print(f"\n[SUCCESS] {product_name} is successfully installed and ready for operations!")
    print("Run `python src/cli.py health` or `python src/cli.py summary` to verify system execution.\n")
    return 0

if __name__ == "__main__":
    sys.exit(main())
