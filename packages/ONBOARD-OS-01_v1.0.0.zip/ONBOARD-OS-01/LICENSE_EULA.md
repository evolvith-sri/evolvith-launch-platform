# ONBOARD-OS-01 — COMMERCIAL LICENSE & END USER LICENSE AGREEMENT (EULA)

> **Product ID**: ONBOARD-OS-01  
> **Product Name**: Customer Onboarding & Activation OS  
> **Version**: 1.0.0  
> **Commercial Tier**: Evolvith Wave 2 Focused Operating System  
> **List Price**: $99 USD (One-Time Payment)  
> **License Model**: Perpetual Commercial License — Single Purchasing Entity  
> **Status**: Implementation License Artifact (Subject to Final Legal Sign-Off)  

---

## 1. GRANT OF LICENSE

Subject to the payment of the applicable one-time license fee ($99 USD), Evolvith grants to the purchasing legal entity or individual business operator ("Licensee") a perpetual, non-exclusive, non-transferable, worldwide commercial license to install, execute, customize, and operate **ONBOARD-OS-01 Customer Onboarding & Activation OS** solely for internal business operations.

---

## 2. SEAT MODEL & SCOPE OF USE

1. **Unlimited Internal Users**: The Licensee may deploy and utilize ONBOARD-OS-01 across an unlimited number of internal Customer Success Managers, onboarding leads, implementation specialists, and customer operations staff within the single purchasing organization.
2. **Single Entity Restriction**: The license is restricted to the single purchasing business entity and its direct operating business units. Sublicensing, reselling, public hosting as a multi-tenant SaaS service, or redistribution of the core source code to third parties is strictly prohibited.
3. **Source Code Access**: Licensee receives full, unencrypted Python source files (`src/engine.py`, `src/cli.py`), JSON schemas (`blueprint.json`), and markdown operational playbooks (`SOP_MANUAL.md`). Licensee is permitted to modify and adapt these files for internal operational integration.

---

## 3. HOSTING & DATA OWNERSHIP

1. **100% Self-Hosted**: ONBOARD-OS-01 is engineered to run entirely within the Licensee's self-hosted, private cloud, or on-premise infrastructure.
2. **Zero Data Ingestion by Evolvith**: Evolvith does not store, transmit, process, or inspect Licensee's customer records, contract terms, customer employee names, or onboarding data.

---

## 4. DISCLAIMERS & CLAIM GOVERNANCE

1. **No Warranty of Specific TTFV or Retention Metrics**: ONBOARD-OS-01 provides deterministic operational software workflows, milestone tracking algorithms, and RACI playbooks. Evolvith does not warrant or guarantee specific customer onboarding velocity, churn reduction, or user adoption rates.
2. **Modeled Targets**: All quantitative outcome figures in product documentation and marketing represent modeled design targets under standardized operational compliance, not historical performance guarantees.
3. **No General Platform Replacement**: ONBOARD-OS-01 is an operational milestone and handoff governance utility and does not constitute a full Customer Success platform or legal contract warranty.

---

*ONBOARD-OS-01 Commercial EULA v1.0.0 — Authoritative.*
