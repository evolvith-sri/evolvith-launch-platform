# ONBOARD-OS-01: Customer Onboarding & Activation OS

> **Evolvith Wave 2 Focused Operating System**  
> **Commercial Tier**: $99 USD One-Time Perpetual Commercial License  
> **Parent Upgrade Vector**: `CX-OS-01 Autonomous Customer Success OS` ($199)  
> **Runtime**: Python 3.9+ | 100% Self-Hosted / Private Cloud  

---

## 1. WHAT PROBLEM ONBOARD-OS-01 SOLVES

In scaling B2B businesses, the gap between closing a deal and realizing live product value is where customer churn begins. While CRMs celebrate the sale, implementation teams struggle with:
- Unstructured Sales-to-CS handoffs and missing project kickoff checklists.
- Implementation gates stalling for weeks due to unflagged customer data bottlenecks.
- Extended Time-to-First-Value (TTFV) that creates customer buyer remorse.
- Lack of clear escalation triggers when enterprise onboarding journeys go dark.

**ONBOARD-OS-01** provides an immediate, executable operating system that ingests active customer onboarding journeys, deterministically tracks progress across a 5-gate lifecycle, flags stalls ($>5\text{ days}$ inactivity), computes TTFV metrics, and triggers 4-tier manager escalations.

---

## 2. WHAT DATA ONBOARD-OS-01 REQUIRES

ONBOARD-OS-01 requires standard customer onboarding records in JSON format:
- `account_id` *(string, required)*: Unique customer identifier (e.g. "ONB-2026-001")
- `account_name` *(string, required)*: Customer / organization name
- `contract_start_date` *(string, required)*: Contract execution date (`YYYY-MM-DD`)
- `current_gate` *(string, required)*: `KICKOFF`, `CONFIGURATION`, `DATA_IMPORT`, `TRAINING`, `GO_LIVE`, `ACTIVATED`, `CANCELLED`
- `plan_tier` *(string, optional)*: `STARTER`, `STANDARD`, `ENTERPRISE`, `CUSTOM`
- `contract_value` *(number, optional)*: Gross contract value / ARR amount
- `assigned_csm` *(string, optional)*: Assigned onboarding lead / CSM
- `gate_entered_at` *(string, optional)*: Date entered current gate (`YYYY-MM-DD`)
- `last_activity_at` *(string, optional)*: Date of last recorded customer interaction (`YYYY-MM-DD`)
- `is_blocked` *(boolean, optional)*: True if customer is blocked by technical/operational hurdle
- `blocker_reason` *(string, optional)*: Plain-text explanation of the blocker

---

## 3. WHAT ONBOARD-OS-01 DOES & PRODUCES

1. **5-Gate Lifecycle State Machine**: Tracks customer progression through Kickoff, Config, Data Import, Training, and Go-Live.
2. **Configurable Milestones**: Allows teams to customize milestone names, SLAs, and sequences in `blueprint.json` without engine changes.
3. **Stall & Bottleneck Detection**: Flags accounts with $> 5\text{ days}$ of inactivity in an onboarding gate.
4. **Time-to-First-Value (TTFV) Analytics**: Computes completed TTFV duration and projects in-flight go-live dates.
5. **Multi-Factor Activation Health Scoring**: Evaluates account health (0–100) and assigns `HEALTHY`, `AT_RISK`, or `CRITICAL` status.
6. **4-Tier RACI Escalation Dispatch**: Triggers proactive alerts from CSM check-ins up to VP Customer Success interventions.

---

## 4. WHAT ONBOARD-OS-01 DOES NOT DO

- It is **NOT** a full Customer Success platform (Gainsight/ChurnZero).
- It does **NOT** build in-app user walkthrough modals or UI tours.
- It does **NOT** scrape real-time product usage telemetry.
- It does **NOT** transmit any customer data to Evolvith servers (100% self-hosted).

---

## 5. QUICKSTART INSTALLATION & USAGE

### Step 1: Run Quickstart Installer
```bash
python install.py
```

### Step 2: Verify System Health
```bash
python src/cli.py health
```

### Step 3: Run Onboarding Audit on Sample Data
```bash
python src/cli.py summary
```

### Step 4: Run on Custom Customer Dataset
```bash
python src/cli.py run --input path/to/my_onboarding.json --output reports/onboarding_audit_output.json
```

---

## 6. CLAIM GOVERNANCE & DISCLAIMERS

> **MODELED TARGET — NOT HISTORICAL PERFORMANCE**  
> All quantitative metrics (e.g. 50% faster TTFV, 60% bottleneck reduction) represent modeled design targets under standard operational compliance, not historical customer performance guarantees. The 5-day stall threshold is a product design default.

---

*ONBOARD-OS-01 User Guide v1.0.0 — Authoritative.*
