# ONBOARD-OS-01 — STANDARD OPERATING PROCEDURES (SOP) & RACI MANUAL

> **Product ID**: ONBOARD-OS-01  
> **System Name**: Customer Onboarding & Activation OS  
> **Version**: 1.0.0  
> **Governance Level**: Operational RACI & Execution Standard  

---

## 1. PURPOSE & SCOPE

### 1.1 Purpose
The purpose of this Standard Operating Procedure (SOP) is to institutionalize a deterministic, repeatable, and disciplined customer implementation process. It eliminates customer churn risk caused by unstructured handoffs from sales, stalled implementation gates, ambiguous milestone ownership, and extended Time-to-First-Value (TTFV).

### 1.2 Scope Boundary
- **In-Scope**: Sales-to-CS kickoff handoff verification, 5-gate onboarding journey orchestration, milestone stall detection, technical blocker logging, activation health scoring, 4-tier manager escalation, and go-live sign-off.
- **Out-of-Scope**: In-app walkthrough modal builders, live product telemetry event ingestion, support helpdesk ticketing, multi-tenant billing administration.

---

## 2. WORKFORCE RACI MATRIX

| Operational Activity | Customer Success Manager | Onboarding / Implementation Lead | VP of Customer Success / Founder | Sales Account Executive |
| :--- | :---: | :---: | :---: | :---: |
| **Sales-to-CS Handoff & Kickoff Scheduling** | **A / R** | **C** | **I** | **R** |
| **Technical Configuration & SSO Setup (Gate 2)** | **C** | **A / R** | **I** | **I** |
| **Data Migration & Schema Validation (Gate 3)** | **I** | **A / R** | **I** | **I** |
| **Stakeholder Training & Enablement (Gate 4)** | **A / R** | **C** | **I** | **I** |
| **Production Go-Live Sign-Off (Gate 5)** | **A / R** | **R** | **I** | **I** |
| **Tier-1 CSM Defect Alerts (Inactivity 3–5d)** | **A / R** | **I** | **I** | **I** |
| **Tier-2 Stalled Onboarding Triage (> 5d / Blocker)** | **R** | **A** | **C** | **C** |
| **Tier-3 High-Value Enterprise Escalation (ARR $\ge \$25K$)** | **R** | **R** | **A** | **C** |

*Legend: **R** = Responsible, **A** = Accountable, **C** = Consulted, **I** = Informed.*

---

## 3. 5-GATE ONBOARDING LIFECYCLE & SIGN-OFF CRITERIA

```
+----------------------------------------------------------------------------------------------------+
|                                    5-GATE ONBOARDING JOURNEY                                       |
+----------------------------------------------------------------------------------------------------+
| GATE 1: KICKOFF (Max 5d)          ──▶ Stakeholder alignment, success criteria, cadence schedule.   |
| GATE 2: CONFIGURATION (Max 7d)    ──▶ Workspace provisioning, SSO, security & admin setup.         |
| GATE 3: DATA IMPORT (Max 7d)      ──▶ Customer legacy data mapped, validated, imported, verified.  |
| GATE 4: TRAINING (Max 5d)         ──▶ User enablement, admin certification, workflow testing.      |
| GATE 5: GO-LIVE (Max 3d)          ──▶ Production launch, first value achieved, CS handoff.         |
+----------------------------------------------------------------------------------------------------+
```

### 3.1 Gate 1: Kickoff & Alignment (Target SLA: 5 Days)
- **Objective**: Conduct formal customer kickoff meeting within 5 business days of contract start.
- **Completion Criteria**: Success metrics documented, executive sponsor identified, weekly working cadence locked.

### 3.2 Gate 2: Workspace & Integration Configuration (Target SLA: 7 Days)
- **Objective**: Provision production environment and establish authentication/SSO protocols.
- **Completion Criteria**: Admin credentials delivered, user roles assigned, security clearance signed off.

### 3.3 Gate 3: Data Migration & Mapping (Target SLA: 7 Days)
- **Objective**: Ingest customer data into standard operating schema.
- **Completion Criteria**: Schema validation tests passed, sample reconciliation verified by client.

### 3.4 Gate 4: Stakeholder Training & Enablement (Target SLA: 5 Days)
- **Objective**: Enable primary operators and departmental champions.
- **Completion Criteria**: Minimum 80% attendance on core training tracks; champion executes live workflow.

### 3.5 Gate 5: Production Go-Live & First Value (Target SLA: 3 Days)
- **Objective**: Transition customer into live operational production.
- **Completion Criteria**: Live data processed, first milestone outcome realized, formal transition to ongoing CSM logged.

---

## 4. 4-TIER ONBOARDING CADENCE & ESCALATION PROTOCOL

```
+----------------------------------------------------------------------------------------------------+
|                                  4-TIER ONBOARDING ESCALATION MODEL                                |
+----------------------------------------------------------------------------------------------------+
| TIER 0: ON TRACK (Healthy)        ──▶ Milestone execution within target SLA; standard check-ins.   |
| TIER 1: CSM ALERT (3–5d Inactive) ──▶ CSM re-engages customer point of contact on pending tasks.  |
| TIER 2: LEAD TRIAGE (Stalled/Blk) ──▶ Onboarding Lead direct intervention to clear technical stalls.|
| TIER 3: EXECUTIVE INTERVENTION    ──▶ VP Customer Success intervention on enterprise/critical deals.|
+----------------------------------------------------------------------------------------------------+
```

---

## 5. OPERATIONAL EXECUTION RUNBOOK (DAILY & WEEKLY)

### Step 1: Ingest Active Onboarding Dataset
Export current implementation accounts from CRM or project tracker into JSON format:
```bash
python src/cli.py summary --input path/to/daily_onboarding.json
```

### Step 2: Review Bottleneck Queue & Action Defective Accounts
Inspect the `OPERATIONAL BOTTLENECK INVENTORY` and `PRIORITY ACTION QUEUE`. Prioritize hard-blocked accounts and unassigned CSM journeys.

### Step 3: Run Weekly Executive Activation Rollup
Generate structured audit snapshot for leadership review:
```bash
python src/cli.py run --input path/to/daily_onboarding.json --output reports/weekly_onboarding_audit.json
```

---

## 6. TIME-TO-FIRST-VALUE (TTFV) GOVERNANCE

1. **Definition**: TTFV is measured as calendar days from `contract_start_date` to `actual_go_live_date`.
2. **Target Benchmark (Modeled Design Default)**: Target standard TTFV is $\le 30\text{ calendar days}$.
3. **Slippage Threshold**: Any customer journey exceeding 45 days elapsed triggers automatic **Tier-3 Executive Intervention**.

---

*ONBOARD-OS-01 SOP Manual v1.0.0 — Authoritative.*
