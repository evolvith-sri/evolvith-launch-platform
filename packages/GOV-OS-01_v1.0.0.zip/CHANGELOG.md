# CHANGELOG — GOV-OS-01

## [1.0.0] - 2026-08-14
- Initial release of GOV-OS-01 Enterprise Governance & Risk OS.
- Executive Decision Registry (EDR), Quality Gate enforcement pipeline, Defect Elimination Protocol (DEP).
