import sys
from .engine import OperatingSystemEngine

def main():
    print("Initializing GOV-OS-01 Enterprise Governance & Risk OS...")
    engine = OperatingSystemEngine()
    result = engine.execute_workflow({"action": "health_check"})
    print(f"Execution Result: {result['status']}")

if __name__ == "__main__":
    main()
