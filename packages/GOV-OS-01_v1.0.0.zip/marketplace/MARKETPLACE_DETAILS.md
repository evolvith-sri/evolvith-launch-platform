# Marketplace Listing Details — GOV-OS-01

- **Title**: Enterprise Governance & Risk OS (GOV-OS-01)
- **Category**: Governance Systems
- **Price**: $149 USD (Perpetual License)
- **Package**: GOV-OS-01_v1.0.0.zip
