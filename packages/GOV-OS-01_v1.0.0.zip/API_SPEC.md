# GOV-OS-01 API & Integration Endpoint Specification

## Endpoints Overview

### `POST /api/v1/edr/log_decision`
- **Description**: Records executive decision into the immutable Executive Decision Registry.
- **Payload**: JSON containing decision_id, sponsor_id, rationale, impact_score, and policy_tags.

### `POST /api/v1/policy/enforce`
- **Description**: Evaluates an operational action against active Quality Gate & policy rulesets.
- **Response**: `{ "status": "APPROVED" | "REJECTED", "violations": [] }`

### `POST /api/v1/dep/report_defect`
- **Description**: Ingests operational defect report into Defect Elimination Protocol workflow engine.
