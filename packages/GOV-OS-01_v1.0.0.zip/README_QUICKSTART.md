# GOV-OS-01 Quickstart Guide

## 48-Hour Rapid Installation Runbook

### Phase 1: 00-12h — Environment Setup
1. Extract release archive `GOV-OS-01_v1.0.0.zip`.
2. Run `python install.py` to initialize virtual environment and dependencies.
3. Validate configuration schema via `config/gov_os_schema.json`.

### Phase 2: 12-24h — EDR Ingestion Setup
1. Initialize Executive Decision Registry (EDR) master log database.
2. Ingest institutional policy rulesets for SOC2, ISO27001, and internal RACI matrices.

### Phase 3: 24-36h — Policy Rule Injection
1. Map automated policy enforcement modules across operating units.
2. Configure Defect Elimination Protocol (DEP) escalation thresholds.

### Phase 4: 36-48h — Telemetry Smoke Testing & Sign-Off
1. Run `python src/cli.py` to verify policy enforcement pipeline.
2. Confirm 100% decision audit trail logging in executive telemetry dashboard.
