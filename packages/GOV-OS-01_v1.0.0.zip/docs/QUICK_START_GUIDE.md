# Quick Start Guide — GOV-OS-01

Fast-track 48-hour setup guide for deploying GOV-OS-01.
