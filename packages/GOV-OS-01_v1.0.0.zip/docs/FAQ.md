# Frequently Asked Questions — GOV-OS-01

### Q: Does GOV-OS-01 support ISO and SOC2 compliance?
Yes, it includes pre-mapped policy rulesets for SOC2, ISO27001, and GDPR compliance.
