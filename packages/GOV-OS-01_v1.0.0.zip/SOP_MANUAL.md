# GOV-OS-01 Enterprise SOP Manual & RACI Matrix

## Operational RACI Matrix

| Task / Workflow | Chief Risk Officer | General Counsel | Exec Board | Operating Lead |
| :--- | :--- | :--- | :--- | :--- |
| **Policy Code Sign-Off**| **Accountable** | Responsible | Consulted | Informed |
| **EDR Logging** | Consulted | **Accountable** | Responsible | Informed |
| **Defect Elimination** | Consulted | Responsible | Informed | **Accountable** |
| **Audit Compliance** | Responsible | **Accountable** | Informed | Informed |

## Standard Operating Procedures
1. **SOP-GOV-01**: Executive Decision Registry Ingestion Standard.
2. **SOP-GOV-02**: Quality Gate Policy Rule Codification Procedure.
3. **SOP-GOV-03**: Defect Elimination Protocol Root-Cause Investigation.
