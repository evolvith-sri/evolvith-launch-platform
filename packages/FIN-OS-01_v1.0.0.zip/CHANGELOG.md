# Changelog — Strategic CFO Decision Intelligence OS

## [1.0.0] - 2026-08-07
- Initial commercial v1.0.0 release manufactured under Genome Alpha.
