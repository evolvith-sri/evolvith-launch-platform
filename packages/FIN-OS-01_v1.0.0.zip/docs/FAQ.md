# FAQ — Strategic CFO Decision Intelligence OS

Q: Is internet connection required?
A: No, executes locally with 100% data privacy.
