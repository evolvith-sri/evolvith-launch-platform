# Quick Start Guide — Strategic CFO Decision Intelligence OS

Deploy in under 5 minutes:
```bash
python install.py
python -m src.cli run
```
