# Troubleshooting Guide — Strategic CFO Decision Intelligence OS

Run diagnostic check: `python -m src.cli health`.
