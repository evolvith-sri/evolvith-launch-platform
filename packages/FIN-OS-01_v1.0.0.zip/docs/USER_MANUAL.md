# User Manual — Strategic CFO Decision Intelligence OS

Complete operational user manual for operating Strategic CFO Decision Intelligence OS.
