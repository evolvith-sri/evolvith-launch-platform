import argparse
from src.engine import OperatingSystemEngine

def main():
    parser = argparse.ArgumentParser(description="Strategic CFO Decision Intelligence OS")
    parser.add_argument("command", choices=["run", "health"])
    args = parser.parse_args()
    engine = OperatingSystemEngine()
    if args.command == "run":
        res = engine.execute_workflow({})
        print(res["output"])
    elif args.command == "health":
        print(engine.health.get_health_status())

if __name__ == "__main__":
    main()
