"""Strategic CFO Decision Intelligence OS src package"""
