# CFO Intelligence OS (FIN-OS-01) — Enterprise SOP Library

> **Repository D Release 1.0 | Wave 1 Commercial Operating System**

---

## 1. SOP-FIN-01: Weekly Cash Flow & Working Capital Review
- **Cadence**: Every Monday at 11:00 AM.
- **Procedure**: Run cash flow diagnostic (`WF-FIN-01`), audit AR/AP aging over 30 days, update treasury summary.

---

*FIN-OS-01 Commercial Operating System — SOP Library.*
