# Frequently Asked Questions — DATA-OS-01

### Q: Is DATA-OS-01 compatible with Snowflake or BigQuery?
Yes, it connects directly to cloud data warehouses including Snowflake, BigQuery, and Databricks via REST APIs and Webhooks.
