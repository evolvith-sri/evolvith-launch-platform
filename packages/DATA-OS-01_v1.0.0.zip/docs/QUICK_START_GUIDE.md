# Quick Start Guide — DATA-OS-01

Fast-track 48-hour setup guide for deploying DATA-OS-01.
