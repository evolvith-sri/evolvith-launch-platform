# CHANGELOG — DATA-OS-01

## [1.0.0] - 2026-08-14
- Initial release of DATA-OS-01 Enterprise Data & Analytics OS.
- Single source of truth metrics layer, vector telemetry pipeline, quality audit engine.
