# Marketplace Listing Details — DATA-OS-01

- **Title**: Enterprise Data & Analytics OS (DATA-OS-01)
- **Category**: Data Systems
- **Price**: $179 USD (Perpetual License)
- **Package**: DATA-OS-01_v1.0.0.zip
