import sys
from .engine import OperatingSystemEngine

def main():
    print("Initializing DATA-OS-01 Enterprise Data & Analytics OS...")
    engine = OperatingSystemEngine()
    result = engine.execute_workflow({"action": "health_check"})
    print(f"Execution Result: {result['status']}")

if __name__ == "__main__":
    main()
