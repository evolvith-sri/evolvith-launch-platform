# DATA-OS-01 Quickstart Guide

## 48-Hour Rapid Installation Runbook

### Phase 1: 00-12h — Environment Setup
1. Extract release archive `DATA-OS-01_v1.0.0.zip`.
2. Run `python install.py` to initialize virtual environment and dependencies.
3. Validate configuration schema via `config/data_os_schema.json`.

### Phase 2: 12-24h — Data Warehouse Integration
1. Configure credentials for Snowflake, BigQuery, or Databricks in environment.
2. Ingest metric registry specifications from `config/metrics_layer_spec.yaml`.

### Phase 3: 24-36h — Metric Governance Alignment
1. Map enterprise KPI definitions across Sales, Finance, and Marketing.
2. Execute data lineage audit scripts.

### Phase 4: 36-48h — Telemetry Smoke Testing & Verification
1. Run `python src/cli.py` to verify system health.
2. Confirm sub-second query latency for executive dashboards.
