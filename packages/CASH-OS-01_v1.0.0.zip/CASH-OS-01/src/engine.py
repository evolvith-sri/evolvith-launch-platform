"""
CASH-OS-01: Execution Engine
Cash Collection & Receivables Execution OS
"""

import sys
import os
from datetime import datetime, date
from typing import List, Dict, Any, Optional

try:
    from factory_core.modules.health import HealthDiagnosticsHandler
except ImportError:
    # Fallback if executed standalone outside factory repository root
    class HealthDiagnosticsHandler:
        def __init__(self, product_id: str):
            self.product_id = product_id
        def get_health_status(self) -> dict:
            return {
                "status": "HEALTHY",
                "product_id": self.product_id,
                "version": "1.0.0",
                "uptime_seconds": 0.0,
                "python_version": sys.version.split()[0],
                "platform": sys.platform,
                "genome_compliance": "GENOME_ALPHA_V1",
                "sla_guarantee_ms": 500
            }


class OperatingSystemEngine:
    """Core workflow execution engine for CASH-OS-01."""

    VALID_PAYMENT_STATUSES = {"OPEN", "PARTIALLY_PAID", "PAID", "DISPUTED", "WRITTEN_OFF"}
    REQUIRED_FIELDS = {"invoice_id", "customer_name", "due_date", "amount"}

    def __init__(self):
        self.product_id = "CASH-OS-01"
        self.product_name = "Cash Collection & Receivables OS"
        self.version = "1.0.0"
        self.health = HealthDiagnosticsHandler(self.product_id)

    def validate_invoice(self, invoice: Dict[str, Any], seen_ids: set) -> Dict[str, Any]:
        """Validates a single invoice record and raises ValueError on invalid schema."""
        if not isinstance(invoice, dict):
            raise ValueError(f"Malformed invoice record: expected dict, received {type(invoice).__name__}")

        # Check required fields
        for field in self.REQUIRED_FIELDS:
            if field not in invoice or invoice[field] is None or str(invoice[field]).strip() == "":
                raise ValueError(f"Missing required field: '{field}' in invoice: {invoice}")

        invoice_id = str(invoice["invoice_id"]).strip()
        if invoice_id in seen_ids:
            raise ValueError(f"Duplicate invoice identifier detected: '{invoice_id}'")
        seen_ids.add(invoice_id)

        # Validate amount
        try:
            amount = float(invoice["amount"])
            if amount < 0:
                raise ValueError(f"Invoice amount cannot be negative: {amount} in invoice '{invoice_id}'")
        except (ValueError, TypeError) as e:
            raise ValueError(f"Invalid amount value in invoice '{invoice_id}': {e}")

        # Validate due_date format (YYYY-MM-DD)
        due_date_str = str(invoice["due_date"]).strip()
        try:
            due_date = datetime.strptime(due_date_str, "%Y-%m-%d").date()
        except ValueError:
            raise ValueError(f"Invalid due_date format '{due_date_str}' in invoice '{invoice_id}'. Expected 'YYYY-MM-DD'.")

        # Validate optional status
        status = str(invoice.get("payment_status", "OPEN")).strip().upper()
        if status not in self.VALID_PAYMENT_STATUSES:
            raise ValueError(f"Invalid payment_status '{status}' in invoice '{invoice_id}'. Valid statuses: {sorted(list(self.VALID_PAYMENT_STATUSES))}")

        return {
            "invoice_id": invoice_id,
            "customer_id": str(invoice.get("customer_id", invoice_id)).strip(),
            "customer_name": str(invoice["customer_name"]).strip(),
            "invoice_date": str(invoice.get("invoice_date", due_date_str)).strip(),
            "due_date": due_date,
            "amount": amount,
            "currency": str(invoice.get("currency", "USD")).strip().upper(),
            "payment_status": status,
            "assigned_owner": str(invoice.get("assigned_owner", "Unassigned")).strip()
        }

    def process_invoice(self, inv: Dict[str, Any], as_of_date: date) -> Dict[str, Any]:
        """Calculates aging, priority score, action plan, and escalation tier for an invoice."""
        due_date: date = inv["due_date"]
        amount: float = inv["amount"]
        status: str = inv["payment_status"]

        days_overdue = (as_of_date - due_date).days

        if status == "PAID":
            return {
                **inv,
                "due_date": due_date.isoformat(),
                "days_overdue": max(0, days_overdue),
                "aging_bucket": "PAID",
                "priority_score": 0.0,
                "priority_level": "CLOSED",
                "recommended_action": "Payment Reconciled — No Action Required",
                "escalation_level": "NONE",
                "action_required": False
            }

        if days_overdue <= 0:
            aging_bucket = "CURRENT"
            priority_level = "LOW"
            recommended_action = "Standard Courtesy Pre-Due Reminder (3 Days Before Due)"
            escalation_level = "NONE"
            action_required = False
            multiplier = 1.0
        elif 1 <= days_overdue <= 30:
            aging_bucket = "OVERDUE_1_30"
            priority_level = "MEDIUM"
            recommended_action = "First Friendly Reminder & Account Statement via Email/Phone"
            escalation_level = "TIER_1_COLLECTOR"
            action_required = True
            multiplier = 1.2
        elif 31 <= days_overdue <= 60:
            aging_bucket = "OVERDUE_31_60"
            priority_level = "HIGH"
            recommended_action = "Urgent Second Demand Notice & Payment Plan Proposal"
            escalation_level = "TIER_2_FINANCE_MANAGER"
            action_required = True
            multiplier = 1.6
        elif 61 <= days_overdue <= 90:
            aging_bucket = "OVERDUE_61_90"
            priority_level = "HIGH"
            recommended_action = "Final Formal Demand Notice & Credit Hold Warning"
            escalation_level = "TIER_2_FINANCE_MANAGER"
            action_required = True
            multiplier = 2.0
        else:
            aging_bucket = "CRITICAL_90_PLUS"
            priority_level = "CRITICAL"
            recommended_action = "Executive Collections Escalation & Immediate Account Freeze"
            escalation_level = "TIER_3_EXECUTIVE_HOLD"
            action_required = True
            multiplier = 2.5

        # Mathematical Priority Score: Amount * (1 + 0.02 * Days Overdue capped at 100) * Bucket Multiplier
        overdue_factor = 1.0 + (0.02 * min(max(0, days_overdue), 100))
        priority_score = round(amount * overdue_factor * multiplier, 2)

        return {
            **inv,
            "due_date": due_date.isoformat(),
            "days_overdue": days_overdue,
            "aging_bucket": aging_bucket,
            "priority_score": priority_score,
            "priority_level": priority_level,
            "recommended_action": recommended_action,
            "escalation_level": escalation_level,
            "action_required": action_required
        }

    def execute_workflow(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """
        Executes end-to-end receivables workflow.
        Accepts: {"invoices": List[dict], "as_of_date": Optional[str]}
        Returns: Structured operational result with receivables analysis, metrics, and priority queue.
        """
        if not isinstance(payload, dict):
            return {
                "status": "ERROR",
                "product_id": self.product_id,
                "error": f"Invalid payload: expected dict, received {type(payload).__name__}",
                "metrics": self.health.get_health_status()
            }

        raw_invoices = payload.get("invoices", [])
        if not isinstance(raw_invoices, list):
            return {
                "status": "ERROR",
                "product_id": self.product_id,
                "error": "Field 'invoices' must be a list",
                "metrics": self.health.get_health_status()
            }

        # Parse reference date
        as_of_str = payload.get("as_of_date")
        if as_of_str:
            try:
                as_of_date = datetime.strptime(str(as_of_str).strip(), "%Y-%m-%d").date()
            except ValueError:
                return {
                    "status": "ERROR",
                    "product_id": self.product_id,
                    "error": f"Invalid as_of_date format '{as_of_str}'. Expected 'YYYY-MM-DD'.",
                    "metrics": self.health.get_health_status()
                }
        else:
            as_of_date = date.today()

        # Validate and process each invoice
        seen_ids = set()
        validated_invoices = []
        try:
            for inv in raw_invoices:
                cleaned = self.validate_invoice(inv, seen_ids)
                processed = self.process_invoice(cleaned, as_of_date)
                validated_invoices.append(processed)
        except ValueError as e:
            return {
                "status": "VALIDATION_FAILED",
                "product_id": self.product_id,
                "error": str(e),
                "metrics": self.health.get_health_status()
            }

        # Sort actionable items by priority_score descending
        action_queue = [
            inv for inv in validated_invoices if inv["action_required"]
        ]
        action_queue.sort(key=lambda x: x["priority_score"], reverse=True)

        # Aggregate Operational Metrics
        total_count = len(validated_invoices)
        total_amount = sum(inv["amount"] for inv in validated_invoices)
        open_invoices = [inv for inv in validated_invoices if inv["payment_status"] != "PAID"]
        total_open_amount = sum(inv["amount"] for inv in open_invoices)
        overdue_invoices = [inv for inv in open_invoices if inv["days_overdue"] > 0]
        total_overdue_amount = sum(inv["amount"] for inv in overdue_invoices)
        critical_invoices = [inv for inv in open_invoices if inv["aging_bucket"] == "CRITICAL_90_PLUS"]
        total_critical_amount = sum(inv["amount"] for inv in critical_invoices)

        # Aging Bucket Breakdown
        buckets = {"CURRENT": 0.0, "OVERDUE_1_30": 0.0, "OVERDUE_31_60": 0.0, "OVERDUE_61_90": 0.0, "CRITICAL_90_PLUS": 0.0, "PAID": 0.0}
        bucket_counts = {"CURRENT": 0, "OVERDUE_1_30": 0, "OVERDUE_31_60": 0, "OVERDUE_61_90": 0, "CRITICAL_90_PLUS": 0, "PAID": 0}
        for inv in validated_invoices:
            b = inv["aging_bucket"]
            buckets[b] = round(buckets[b] + inv["amount"], 2)
            bucket_counts[b] += 1

        # Estimated DSO approximation (Overdue days weighted by open amount)
        if total_open_amount > 0:
            weighted_days = sum(max(0, inv["days_overdue"]) * inv["amount"] for inv in open_invoices)
            avg_dso_overdue_days = round(weighted_days / total_open_amount, 1)
        else:
            avg_dso_overdue_days = 0.0

        operational_summary = {
            "as_of_date": as_of_date.isoformat(),
            "total_invoices_audited": total_count,
            "total_gross_receivables": round(total_amount, 2),
            "total_open_receivables": round(total_open_amount, 2),
            "total_overdue_receivables": round(total_overdue_amount, 2),
            "overdue_ratio_percentage": round((total_overdue_amount / total_open_amount * 100) if total_open_amount > 0 else 0.0, 1),
            "critical_exposure_90d_plus": round(total_critical_amount, 2),
            "weighted_average_overdue_days": avg_dso_overdue_days,
            "action_queue_count": len(action_queue),
            "aging_distribution_amount": buckets,
            "aging_distribution_count": bucket_counts
        }

        return {
            "status": "SUCCESS",
            "product_id": self.product_id,
            "product_name": self.product_name,
            "version": self.version,
            "summary": operational_summary,
            "priority_action_queue": action_queue,
            "invoices": validated_invoices,
            "metrics": self.health.get_health_status()
        }
