"""
CASH-OS-01: Command-Line Interface (CLI)
Cash Collection & Receivables Execution OS
"""

import sys
import json
import argparse
from pathlib import Path
from typing import Optional

# Ensure package path is resolvable
current_dir = Path(__file__).resolve().parent
product_root = current_dir.parent
if str(product_root) not in sys.path:
    sys.path.insert(0, str(product_root))

from src.engine import OperatingSystemEngine


def format_currency(val: float, currency: str = "USD") -> str:
    return f"{currency} {val:,.2f}"


def print_summary_table(result: dict):
    if result.get("status") != "SUCCESS":
        print(f"[ERROR] Workflow failed: {result.get('error')}")
        return

    summary = result["summary"]
    print("\n" + "=" * 78)
    print("  CASH-OS-01: RECEIVABLES EXECUTION & AGING AUDIT SUMMARY")
    print("=" * 78)
    print(f"  Audit Reference Date       : {summary['as_of_date']}")
    print(f"  Total Invoices Audited     : {summary['total_invoices_audited']}")
    print(f"  Total Open Receivables     : {format_currency(summary['total_open_receivables'])}")
    print(f"  Total Overdue Amount       : {format_currency(summary['total_overdue_receivables'])} ({summary['overdue_ratio_percentage']}%)")
    print(f"  Critical 90d+ Exposure     : {format_currency(summary['critical_exposure_90d_plus'])}")
    print(f"  Weighted Average Overdue   : {summary['weighted_average_overdue_days']} days")
    print("-" * 78)
    print("  AGING BUCKET BREAKDOWN:")
    for bucket, amount in summary["aging_distribution_amount"].items():
        count = summary["aging_distribution_count"].get(bucket, 0)
        print(f"    - {bucket:<18}: {format_currency(amount):>16} ({count:>2} invoices)")
    print("-" * 78)

    queue = result.get("priority_action_queue", [])
    print(f"  PRIORITY ACTION QUEUE (Top {min(5, len(queue))} of {len(queue)} items requiring immediate action):")
    if not queue:
        print("    [OK] No overdue action items required. All receivables current or paid.")
    else:
        for idx, item in enumerate(queue[:5], 1):
            print(f"    {idx}. [{item['priority_level']}] {item['invoice_id']} | {item['customer_name']}")
            print(f"       Amount: {format_currency(item['amount'], item['currency'])} | {item['days_overdue']} days overdue | Owner: {item['assigned_owner']}")
            print(f"       Action: {item['recommended_action']}")
            print(f"       Escalation: {item['escalation_level']}")
    print("=" * 78 + "\n")


def main():
    parser = argparse.ArgumentParser(
        description="CASH-OS-01: Cash Collection & Receivables Execution OS CLI"
    )
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # Command: health
    subparsers.add_parser("health", help="Execute system health & diagnostics check")

    # Command: run
    run_parser = subparsers.add_parser("run", help="Execute receivables workflow on invoice dataset")
    run_parser.add_argument(
        "--input", "-i",
        type=str,
        default=str(product_root / "samples" / "synthetic_invoices.json"),
        help="Path to JSON file containing invoices payload"
    )
    run_parser.add_argument(
        "--output", "-o",
        type=str,
        help="Optional path to write JSON output result"
    )
    run_parser.add_argument(
        "--as-of-date", "-d",
        type=str,
        help="Optional audit reference date (YYYY-MM-DD)"
    )

    # Command: summary
    summary_parser = subparsers.add_parser("summary", help="Run audit and print human-readable operational table")
    summary_parser.add_argument(
        "--input", "-i",
        type=str,
        default=str(product_root / "samples" / "synthetic_invoices.json"),
        help="Path to JSON file containing invoices payload"
    )
    summary_parser.add_argument(
        "--as-of-date", "-d",
        type=str,
        help="Optional audit reference date (YYYY-MM-DD)"
    )

    args = parser.parse_args()
    engine = OperatingSystemEngine()

    if args.command == "health":
        health_status = engine.health.get_health_status()
        print(json.dumps(health_status, indent=2))
        return

    if args.command in ["run", "summary"]:
        input_path = Path(args.input)
        if not input_path.exists():
            print(f"[ERROR] Input dataset file not found: '{input_path}'", file=sys.stderr)
            sys.exit(1)

        try:
            with open(input_path, "r", encoding="utf-8") as f:
                data = json.load(f)
        except Exception as e:
            print(f"[ERROR] Failed to read JSON from '{input_path}': {e}", file=sys.stderr)
            sys.exit(1)

        payload = {"invoices": data if isinstance(data, list) else data.get("invoices", [])}
        if args.as_of_date:
            payload["as_of_date"] = args.as_of_date

        res = engine.execute_workflow(payload)

        if args.command == "summary":
            print_summary_table(res)
        else:
            json_output = json.dumps(res, indent=2)
            if args.output:
                output_path = Path(args.output)
                output_path.parent.mkdir(parents=True, exist_ok=True)
                with open(output_path, "w", encoding="utf-8") as f:
                    f.write(json_output)
                print(f"[SUCCESS] Workflow executed. Result written to '{output_path}'")
            else:
                print(json_output)

        if res.get("status") != "SUCCESS":
            sys.exit(1)
        return

    parser.print_help()


if __name__ == "__main__":
    main()
