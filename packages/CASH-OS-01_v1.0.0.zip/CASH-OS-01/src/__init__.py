"""
CASH-OS-01: Cash Collection & Receivables Execution OS
Evolvith Wave 2 Focused Operating System
"""

from .engine import OperatingSystemEngine

__version__ = "1.0.0"
__all__ = ["OperatingSystemEngine"]
