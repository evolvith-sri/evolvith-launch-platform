# CASH-OS-01 — USER MANUAL & OPERATOR GUIDE

> **Product ID**: CASH-OS-01  
> **Audience**: Accounts Receivable Specialists, Collectors, Accounting Clerks  

---

## 1. DAILY OPERATOR WORKFLOW

1. **Step 1 — Morning Health Check**:
   ```bash
   python src/cli.py health
   ```
   Confirm output status is `HEALTHY`.

2. **Step 2 — Generate Aging Triage Table**:
   ```bash
   python src/cli.py summary
   ```
   Inspect the `PRIORITY ACTION QUEUE` table.

3. **Step 3 — Execute Outreach by Priority**:
   - Begin with Tier-3 Critical accounts (>90 days). Notify Finance Lead.
   - Proceed to Tier-2 Urgent accounts (31–90 days). Send formal demand template and call AP contacts.
   - Complete Tier-1 Friendly reminders (1–30 days).

4. **Step 4 — Record Notes & Update ERP Status**:
   Log customer payment promises or dispute codes into your primary billing system.

---

*CASH-OS-01 User Manual v1.0.0 — Authoritative.*
