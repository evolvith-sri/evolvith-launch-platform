# CASH-OS-01: Cash Collection & Receivables Execution OS

> **Evolvith Wave 2 Focused Operating System**  
> **Commercial Tier**: $99 USD One-Time Perpetual Commercial License  
> **Parent Upgrade Vector**: `FIN-OS-01 Enterprise Financial Intelligence OS` ($349)  
> **Runtime**: Python 3.9+ | 100% Self-Hosted / Private Cloud  

---

## 1. WHAT PROBLEM CASH-OS-01 SOLVES

In growing B2B businesses, overdue invoices and uncollected accounts receivable create severe working capital drag. Most finance teams rely on disorganized email threads, static spreadsheet exports, and ad-hoc follow-ups, resulting in:
- Unclear collector ownership and missed follow-up dates.
- High-value overdue accounts slipping past 60 and 90 days without escalation.
- Lack of structured dunning cadence and credit hold governance.

**CASH-OS-01** provides an immediate, executable operating system that ingests open invoices, deterministically calculates aging buckets, ranks accounts by risk-weighted priority score, dispatches 4-tier action plans, and produces executive aging summaries.

---

## 2. WHAT DATA CASH-OS-01 REQUIRES

CASH-OS-01 requires only standard invoice records in JSON format (exported from QuickBooks, Xero, NetSuite, Stripe, or internal databases):
- `invoice_id` *(string, required)*: Unique invoice identifier (e.g. "INV-2026-001")
- `customer_name` *(string, required)*: Debtor or account name
- `due_date` *(string, required)*: Maturity date in `YYYY-MM-DD` format
- `amount` *(number, required)*: Gross invoice amount
- `payment_status` *(string, optional)*: "OPEN", "PARTIALLY_PAID", "PAID", "DISPUTED"
- `assigned_owner` *(string, optional)*: Collector or account manager

---

## 3. WHAT CASH-OS-01 DOES & PRODUCES

1. **Deterministic Aging Bucketing**: Segregates invoices into `CURRENT`, `OVERDUE_1_30`, `OVERDUE_31_60`, `OVERDUE_61_90`, and `CRITICAL_90_PLUS`.
2. **Mathematical Risk-Weighted Priority Scoring**: Computes $\text{Amount} \times \text{Aging Velocity}$ to instantly surface which accounts require immediate executive attention.
3. **4-Tier Action & Escalation Assignment**: Automatically prescribes specific outreach actions from friendly courtesy statements up to executive service freezes.
4. **Executive Operational Summary**: Computes total open exposure, overdue ratios, weighted DSO estimates, and aging distribution tables.

---

## 4. WHAT CASH-OS-01 DOES NOT DO

- It is **NOT** a general accounting ledger or ERP replacement.
- It does **NOT** process live credit card transactions or banking withdrawals.
- It does **NOT** file legal bankruptcy claims or external debt collection lawsuits.
- It does **NOT** transmit any financial data to Evolvith servers (100% self-hosted).

---

## 5. QUICKSTART INSTALLATION & USAGE

### Step 1: Run Quickstart Installer
```bash
python install.py
```

### Step 2: Verify System Health
```bash
python src/cli.py health
```

### Step 3: Run Receivables Audit on Sample Data
```bash
python src/cli.py summary
```

### Step 4: Run on Custom Invoices Dataset
```bash
python src/cli.py run --input path/to/my_invoices.json --output reports/ar_audit_output.json
```

---

## 6. CLAIM GOVERNANCE & DISCLAIMERS

> **MODELED TARGET — NOT HISTORICAL PERFORMANCE**  
> All quantitative metrics (e.g. 40% recovery acceleration, 65% critical exposure reduction) represent modeled design targets under standard operational compliance, not historical customer performance guarantees.

---

*CASH-OS-01 User Guide v1.0.0 — Authoritative.*
