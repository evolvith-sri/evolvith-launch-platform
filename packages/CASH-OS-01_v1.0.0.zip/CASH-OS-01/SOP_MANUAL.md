# CASH-OS-01 — STANDARD OPERATING PROCEDURES (SOP) & RACI MANUAL

> **Product ID**: CASH-OS-01  
> **System Name**: Cash Collection & Receivables Execution OS  
> **Version**: 1.0.0  
> **Governance Level**: Operational RACI & Execution Standard  

---

## 1. PURPOSE & SCOPE

### 1.1 Purpose
The purpose of this Standard Operating Procedure (SOP) is to institutionalize a deterministic, repeatable, and disciplined accounts receivable (A/R) collection workflow across the organization. It eliminates payment delays caused by inconsistent follow-ups, unclear collector assignments, and lack of structured escalation triggers.

### 1.2 Scope Boundary
- **In-Scope**: Invoice aging calculation, risk-weighted priority triage, daily collection outreach cadences, formal demand notice dispatches, Tier-3 account freezes, and reconciliation reporting.
- **Out-of-Scope**: Statutory tax accounting, multi-currency ledger adjustments, direct merchant payment gateway processing, third-party legal debt litigation.

---

## 2. WORKFORCE RACI MATRIX

| Operational Activity | Accounts Receivable Collector | Finance Operations Lead | Corporate Controller / VP Finance | Account Executive / Sales Lead |
| :--- | :---: | :---: | :---: | :---: |
| **Daily Ingestion & Aging Queue Generation** | **R** | **A** | **I** | **I** |
| **Tier-1 Courtesy & Friendly Follow-Ups (1–30d)** | **A / R** | **I** | **I** | **I** |
| **Tier-2 Formal Demand & Payment Plans (31–60d)** | **R** | **A** | **C** | **C** |
| **Tier-2 Credit Hold Warning Issuance (61–90d)** | **R** | **A** | **C** | **C** |
| **Tier-3 Executive Freeze & Service Hold (90d+)** | **I** | **R** | **A** | **C** |
| **Dispute Logging & Contract Review** | **R** | **A** | **C** | **C** |
| **Monthly A/R Bad-Debt Provision Review** | **I** | **R** | **A** | **I** |

*Legend: **R** = Responsible, **A** = Accountable, **C** = Consulted, **I** = Informed.*

---

## 3. 4-TIER COLLECTIONS CADENCE & ESCALATION PROTOCOL

```
+----------------------------------------------------------------------------------------------------+
|                                    4-TIER ESCALATION CADENCE                                        |
+----------------------------------------------------------------------------------------------------+
| TIER 0: CURRENT (<= 0 Days)       ──▶ Automated Courtesy Pre-Due Reminder (3 Days Prior)           |
| TIER 1: OVERDUE (1–30 Days)       ──▶ Friendly Statement Dispatch via Email & Direct Phone Check   |
| TIER 2: URGENT (31–60 Days)       ──▶ Formal Demand Notice & Structured Payment Plan Proposal      |
| TIER 2: SEVERE (61–90 Days)       ──▶ Final Demand Notice with 7-Day Credit Hold Warning           |
| TIER 3: CRITICAL (90+ Days)       ──▶ Account Suspension, Service Freeze, Executive Legal Review   |
+----------------------------------------------------------------------------------------------------+
```

### 3.1 Tier-0: Pre-Due Courtesy Reminders (T-3 Days)
- **Target**: Current open invoices maturing within 72 hours.
- **Action**: Automated friendly notification confirming receipt of invoice and designated payment method.
- **Objective**: Ensure invoice is processed in customer's upcoming accounts payable payment cycle.

### 3.2 Tier-1: Initial Overdue Cadence (1–30 Days)
- **Target**: Invoices past due date up to 30 calendar days.
- **Action**: Collector sends standardized Statement of Account via email within 48 hours of due-date breach. Follow up with telephone outreach if no response within 5 business days.
- **Tone**: Professional, customer-centric, verifying invoice receipt and payment scheduled date.

### 3.3 Tier-2: Formal Demand & Credit Warnings (31–90 Days)
- **31–60 Days**: Urgent Notice issued by Finance Operations Lead. Propose structured 2-to-3 installment payment plan if client cites temporary cash flow constraints.
- **61–90 Days**: Formal Demand Notice issued by Controller. Explicitly informs client that failure to settle balance within 7 business days will result in credit terms revocation and service delivery hold.

### 3.4 Tier-3: Executive Hold & Legal Referral (90+ Days)
- **Action**: Immediate suspension of customer software access, product deliveries, or service engagements.
- **Approval**: Requires written sign-off from Corporate Controller and notification to Account Executive.
- **Status**: Account transferred to doubtful accounts reserve and evaluated for external collections/arbitration.

---

## 4. OPERATIONAL EXECUTION RUNBOOK (DAILY WORKFLOW)

### Step 1: Ingest Daily Invoice Dataset
Export current accounts receivable ledger from internal accounting/CRM system into JSON format (or run automated webhook ingestion):
```bash
python src/cli.py summary --input path/to/daily_invoices.json
```

### Step 2: Review Prioritized Action Queue
Inspect the output `PRIORITY ACTION QUEUE`. Focus collector outreach on top risk-weighted accounts (highest product of amount and aging velocity).

### Step 3: Dispatch Notifications & Log Customer Commitments
Execute outreach according to Tier guidelines. Record any stated payment commitment dates or dispute reasons.

### Step 4: Generate Executive Receivables Snapshot
Run weekly operational roll-up:
```bash
python src/cli.py run --input path/to/daily_invoices.json --output reports/weekly_ar_audit.json
```

---

## 5. EXCEPTION HANDLING & DISPUTE PROTOCOL

1. **Billing Disputes (Incorrect Amount / Missing Deliverable)**:
   - Freeze aging timer for the disputed portion.
   - Assign investigation ticket to Sales/Operations lead within 24 hours.
   - Undisputed portion must be paid immediately under standard terms.
2. **Short Payments / Unapplied Credits**:
   - Reconcile unapplied credit memos against open balance within 48 hours.
3. **Customer Insolvency / Bankruptcy Notification**:
   - Immediate Tier-3 freeze. Route file directly to Legal Counsel and Controller.

---

*CASH-OS-01 SOP Manual v1.0.0 — Authoritative.*
