# CASH-OS-01 — INTERFACE SPECIFICATION & INTEGRATION BOUNDARY

> **Product ID**: CASH-OS-01  
> **Document Type**: Technical Interface Specification / Integration Contract  
> **Status**: Interface Contract Specification (Self-Hosted / Local Execution)  
> **Note**: This document defines the payload contracts for connecting internal billing systems (QuickBooks, NetSuite, Stripe, Xero) to CASH-OS-01. Live third-party API adapters are executed within customer infrastructure.  

---

## 1. INGESTION DATA CONTRACT (JSON SCHEMA)

### Inbound Invoices Array Payload: `POST /api/v1/receivables/ingest`
```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "title": "CashOSInboundInvoices",
  "type": "object",
  "required": ["invoices"],
  "properties": {
    "as_of_date": {
      "type": "string",
      "format": "date",
      "description": "Optional audit reference date (YYYY-MM-DD). Defaults to current execution date."
    },
    "invoices": {
      "type": "array",
      "items": {
        "type": "object",
        "required": ["invoice_id", "customer_name", "due_date", "amount"],
        "properties": {
          "invoice_id": { "type": "string" },
          "customer_id": { "type": "string" },
          "customer_name": { "type": "string" },
          "invoice_date": { "type": "string", "format": "date" },
          "due_date": { "type": "string", "format": "date" },
          "amount": { "type": "number", "minimum": 0 },
          "currency": { "type": "string", "default": "USD" },
          "payment_status": { 
            "type": "string", 
            "enum": ["OPEN", "PARTIALLY_PAID", "PAID", "DISPUTED", "WRITTEN_OFF"],
            "default": "OPEN"
          },
          "assigned_owner": { "type": "string", "default": "Unassigned" }
        }
      }
    }
  }
}
```

---

## 2. OUTBOUND WORKFLOW EXECUTION CONTRACT

### Response Payload Schema: `200 OK`
```json
{
  "status": "SUCCESS",
  "product_id": "CASH-OS-01",
  "product_name": "Cash Collection & Receivables OS",
  "version": "1.0.0",
  "summary": {
    "as_of_date": "2026-08-17",
    "total_invoices_audited": 20,
    "total_gross_receivables": 250000.00,
    "total_open_receivables": 220000.00,
    "total_overdue_receivables": 145000.00,
    "overdue_ratio_percentage": 65.9,
    "critical_exposure_90d_plus": 45000.00,
    "weighted_average_overdue_days": 38.4,
    "action_queue_count": 12,
    "aging_distribution_amount": {
      "CURRENT": 75000.00,
      "OVERDUE_1_30": 40000.00,
      "OVERDUE_31_60": 35000.00,
      "OVERDUE_61_90": 25000.00,
      "CRITICAL_90_PLUS": 45000.00,
      "PAID": 30000.00
    },
    "aging_distribution_count": {
      "CURRENT": 5,
      "OVERDUE_1_30": 4,
      "OVERDUE_31_60": 3,
      "OVERDUE_61_90": 2,
      "CRITICAL_90_PLUS": 3,
      "PAID": 3
    }
  },
  "priority_action_queue": [
    {
      "invoice_id": "INV-2026-004",
      "customer_name": "Delta Energy Partners",
      "amount": 67500.00,
      "currency": "USD",
      "due_date": "2026-05-10",
      "days_overdue": 99,
      "aging_bucket": "CRITICAL_90_PLUS",
      "priority_score": 502875.00,
      "priority_level": "CRITICAL",
      "recommended_action": "Executive Collections Escalation & Immediate Account Freeze",
      "escalation_level": "TIER_3_EXECUTIVE_HOLD",
      "assigned_owner": "Elena Vance (Finance Manager)"
    }
  ],
  "metrics": {
    "status": "HEALTHY",
    "product_id": "CASH-OS-01",
    "version": "1.0.0"
  }
}
```

---

## 3. WEBHOOK EVENT CONTRACTS (OUTBOUND ALERTS)

1. **`receivables.escalation.triggered`**: Dispatched when an invoice enters `TIER_2_FINANCE_MANAGER` or `TIER_3_EXECUTIVE_HOLD`.
2. **`receivables.daily_summary.published`**: Dispatched following completion of daily aging triage.

---

*CASH-OS-01 API Specification v1.0.0 — Authoritative.*
