# Quick Start Guide — Document Intelligence & Contract Extraction OS

Deploy in under 5 minutes:
```bash
python install.py
python -m src.cli run
```
