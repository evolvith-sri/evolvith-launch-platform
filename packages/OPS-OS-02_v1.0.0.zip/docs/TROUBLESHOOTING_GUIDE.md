# Troubleshooting Guide — Document Intelligence & Contract Extraction OS

Run diagnostic check: `python -m src.cli health`.
