# Version History — Document Intelligence & Contract Extraction OS

- v1.0.0 (Current): First Commercial Manufacture.
