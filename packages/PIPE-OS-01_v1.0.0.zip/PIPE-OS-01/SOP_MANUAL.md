# PIPE-OS-01 — STANDARD OPERATING PROCEDURES (SOP) & RACI MANUAL

> **Product ID**: PIPE-OS-01  
> **System Name**: Lead & Pipeline Execution OS  
> **Version**: 1.0.0  
> **Governance Level**: Operational RACI & Execution Standard  

---

## 1. PURPOSE & SCOPE

### 1.1 Purpose
The purpose of this Standard Operating Procedure (SOP) is to enforce rigorous operational hygiene, next-action accountability, and structured escalation across the sales pipeline. It eliminates deal slippage caused by dormant opportunities, vague qualification criteria, unassigned deal ownership, and missed follow-ups.

### 1.2 Scope Boundary
- **In-Scope**: Opportunity qualification validation, stage stall detection, missing next-action triage, follow-up SLA enforcement, Tier-1 through Tier-3 manager escalation, and executive pipeline hygiene roll-ups.
- **Out-of-Scope**: Contact management database, cold outbound prospecting, marketing email automation, CPQ billing configuration, commission compensation calculation.

---

## 2. WORKFORCE RACI MATRIX

| Operational Activity | Account Executive / Sales Rep | Sales Operations Lead | Sales Manager | VP of Sales / Founder |
| :--- | :---: | :---: | :---: | :---: |
| **Daily Next-Action Logging & Follow-Up Updates** | **A / R** | **I** | **I** | **I** |
| **Daily Pipeline Audit Ingestion & Defect Triage** | **I** | **A / R** | **C** | **I** |
| **Tier-1 Rep Defect Alerts (Missing Next Actions)** | **R** | **A** | **I** | **I** |
| **Tier-2 Stalled Deal Review & Re-Qualification** | **R** | **C** | **A** | **I** |
| **Tier-3 High-Value Deal Intervention (> $25K)** | **R** | **I** | **C** | **A** |
| **Weekly Pipeline Hygiene & Stage Gate Audit** | **I** | **R** | **A** | **C** |
| **Disqualified / Lost Deal Post-Mortem Logging** | **R** | **I** | **A** | **I** |

*Legend: **R** = Responsible, **A** = Accountable, **C** = Consulted, **I** = Informed.*

---

## 3. 4-TIER PIPELINE CADENCE & ESCALATION PROTOCOL

```
+----------------------------------------------------------------------------------------------------+
|                                    4-TIER PIPELINE ESCALATION CADENCE                              |
+----------------------------------------------------------------------------------------------------+
| TIER 0: ON TRACK (Healthy)         ──▶ Maintain Standard Scheduled Milestone Cadence               |
| TIER 1: REP ALERT (1 Defect)       ──▶ Rep Notification: Assign Next Action or Update Follow-Up     |
| TIER 2: MANAGER REVIEW (Stalled)   ──▶ Sales Manager 1-on-1 Review & Qualification Re-Assessment    |
| TIER 3: EXECUTIVE INTERVENTION     ──▶ VP Sales / Executive Sponsor Direct Deal Rescue Cadence     |
+----------------------------------------------------------------------------------------------------+
```

### 3.1 Tier-0: Healthy Opportunities
- **Criteria**: Opportunity has an active owner, clear qualification status, scheduled next action in the future, and < 14 days of inactivity.
- **Action**: Rep executes scheduled customer milestones according to sales playbook.

### 3.2 Tier-1: Operational Hygiene Alerts
- **Criteria**: Missing next action, overdue follow-up (< 7 days), or unassigned owner in early stages (`PROSPECTING`/`QUALIFICATION`).
- **Action**: Sales Operations generates daily triage alert. Rep must update next action and customer commitment date within 24 hours.

### 3.3 Tier-2: Stalled & Qualification Escalation
- **Criteria**: Opportunity inactive > 14 days, in stage > 30 days, or advanced to `PROPOSAL`/`NEGOTIATION` with `INCOMPLETE` qualification.
- **Action**: Sales Manager reviews deal during weekly pipeline 1-on-1. Rep must present an actionable path to milestone progression or disqualify the deal.

### 3.4 Tier-3: High-Value Deal Executive Intervention
- **Criteria**: High-value opportunity ($\ge \$25,000$) stalled in `PROPOSAL` or `NEGOTIATION` stages.
- **Action**: Mandatory escalation to VP of Sales. Executive sponsor outreach is scheduled with customer decision-makers to unblock stalled contractual or technical reviews.

---

## 4. OPERATIONAL EXECUTION RUNBOOK (DAILY & WEEKLY)

### Step 1: Ingest Pipeline Dataset
Export opportunity snapshot from CRM/database into JSON format and execute triage:
```bash
python src/cli.py summary --input path/to/daily_pipeline.json
```

### Step 2: Review Defect Queue & Assign Fixes
Inspect the output table. Triage opportunities with missing next actions and unassigned owners.

### Step 3: Run Weekly Manager Rollup
Generate structured audit snapshot for executive review:
```bash
python src/cli.py run --input path/to/daily_pipeline.json --output reports/weekly_pipeline_audit.json
```

---

## 5. EXCEPTION HANDLING & DEAL DISQUALIFICATION

1. **Unresponsive Customers (Ghosting)**:
   - After 3 documented outreach attempts over 14 days without customer response, move stage to `CLOSED_LOST` with reason `NO_RESPONSE`.
2. **Budget Freezes / Delayed Projects**:
   - Change status to `ON_HOLD` with target revisit date; remove from active pipeline calculation.
3. **Competitive Losses**:
   - Log specific primary competitor and reason for loss before marking `CLOSED_LOST`.

---

*PIPE-OS-01 SOP Manual v1.0.0 — Authoritative.*
