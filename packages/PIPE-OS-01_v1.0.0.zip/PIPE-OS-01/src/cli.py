"""
PIPE-OS-01: Command-Line Interface (CLI)
Lead & Pipeline Execution OS
"""

import sys
import json
import argparse
from pathlib import Path
from typing import Optional

# Ensure package path is resolvable
current_dir = Path(__file__).resolve().parent
product_root = current_dir.parent
if str(product_root) not in sys.path:
    sys.path.insert(0, str(product_root))

from src.engine import OperatingSystemEngine


def format_currency(val: float, currency: str = "USD") -> str:
    return f"{currency} {val:,.2f}"


def print_summary_table(result: dict):
    if result.get("status") != "SUCCESS":
        print(f"[ERROR] Workflow failed: {result.get('error')}")
        return

    summary = result["summary"]
    print("\n" + "=" * 80)
    print("  PIPE-OS-01: LEAD & PIPELINE EXECUTION AUDIT SUMMARY")
    print("=" * 80)
    print(f"  Audit Reference Date         : {summary['as_of_date']}")
    print(f"  Total Opportunities Audited  : {summary['total_opportunities_audited']}")
    print(f"  Total Pipeline Gross Value   : {format_currency(summary['total_pipeline_value'])}")
    print(f"  Active Open Pipeline Value   : {format_currency(summary['active_pipeline_value'])}")
    print(f"  Stalled Pipeline Exposure    : {format_currency(summary['stalled_pipeline_value'])} ({summary['stalled_pipeline_ratio_percentage']}%)")
    print("-" * 80)
    print("  OPERATIONAL DEFECT INVENTORY:")
    print(f"    - Missing Next Action      : {summary['missing_next_action_count']} deals")
    print(f"    - Overdue Follow-Ups       : {summary['overdue_followup_count']} deals")
    print(f"    - Unassigned Owners        : {summary['unassigned_owner_count']} deals")
    print(f"    - Qualification Gaps       : {summary['qualification_gaps_count']} deals")
    print("-" * 80)
    print("  STAGE DISTRIBUTION:")
    for stage, amount in summary["stage_distribution_value"].items():
        count = summary["stage_distribution_count"].get(stage, 0)
        print(f"    - {stage:<16}: {format_currency(amount):>16} ({count:>2} opportunities)")
    print("-" * 80)

    queue = result.get("priority_action_queue", [])
    print(f"  PRIORITY ACTION QUEUE (Top {min(5, len(queue))} of {len(queue)} items requiring immediate triage):")
    if not queue:
        print("    [OK] No pipeline defects detected. All opportunities on schedule.")
    else:
        for idx, item in enumerate(queue[:5], 1):
            print(f"    {idx}. [{item['risk_level']}] {item['opportunity_id']} | {item['account_name']} ({item['stage']})")
            print(f"       Value: {format_currency(item['value'], item['currency'])} | Owner: {item['owner']} | Days Inactive: {item['days_inactive']}")
            print(f"       Action: {item['recommended_action']}")
            print(f"       Escalation: {item['escalation_level']}")
    print("=" * 80 + "\n")


def main():
    parser = argparse.ArgumentParser(
        description="PIPE-OS-01: Lead & Pipeline Execution OS CLI"
    )
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # Command: health
    subparsers.add_parser("health", help="Execute system health & diagnostics check")

    # Command: run
    run_parser = subparsers.add_parser("run", help="Execute pipeline execution audit on opportunity dataset")
    run_parser.add_argument(
        "--input", "-i",
        type=str,
        default=str(product_root / "samples" / "synthetic_pipeline.json"),
        help="Path to JSON file containing opportunities payload"
    )
    run_parser.add_argument(
        "--output", "-o",
        type=str,
        help="Optional path to write JSON output result"
    )
    run_parser.add_argument(
        "--as-of-date", "-d",
        type=str,
        help="Optional audit reference date (YYYY-MM-DD)"
    )

    # Command: summary
    summary_parser = subparsers.add_parser("summary", help="Run audit and print human-readable operational table")
    summary_parser.add_argument(
        "--input", "-i",
        type=str,
        default=str(product_root / "samples" / "synthetic_pipeline.json"),
        help="Path to JSON file containing opportunities payload"
    )
    summary_parser.add_argument(
        "--as-of-date", "-d",
        type=str,
        help="Optional audit reference date (YYYY-MM-DD)"
    )

    args = parser.parse_args()
    engine = OperatingSystemEngine()

    if args.command == "health":
        health_status = engine.health.get_health_status()
        print(json.dumps(health_status, indent=2))
        return

    if args.command in ["run", "summary"]:
        input_path = Path(args.input)
        if not input_path.exists():
            print(f"[ERROR] Input dataset file not found: '{input_path}'", file=sys.stderr)
            sys.exit(1)

        try:
            with open(input_path, "r", encoding="utf-8") as f:
                data = json.load(f)
        except Exception as e:
            print(f"[ERROR] Failed to read JSON from '{input_path}': {e}", file=sys.stderr)
            sys.exit(1)

        payload = {"opportunities": data if isinstance(data, list) else data.get("opportunities", [])}
        if args.as_of_date:
            payload["as_of_date"] = args.as_of_date

        res = engine.execute_workflow(payload)

        if args.command == "summary":
            print_summary_table(res)
        else:
            json_output = json.dumps(res, indent=2)
            if args.output:
                output_path = Path(args.output)
                output_path.parent.mkdir(parents=True, exist_ok=True)
                with open(output_path, "w", encoding="utf-8") as f:
                    f.write(json_output)
                print(f"[SUCCESS] Workflow executed. Result written to '{output_path}'")
            else:
                print(json_output)

        if res.get("status") != "SUCCESS":
            sys.exit(1)
        return

    parser.print_help()


if __name__ == "__main__":
    main()
