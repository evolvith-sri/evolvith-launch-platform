"""
PIPE-OS-01: Lead & Pipeline Execution OS
Evolvith Wave 2 Focused Operating System
"""

from .engine import OperatingSystemEngine

__version__ = "1.0.0"
__all__ = ["OperatingSystemEngine"]
