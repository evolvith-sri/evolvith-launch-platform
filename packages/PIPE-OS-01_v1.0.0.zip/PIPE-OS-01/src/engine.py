"""
PIPE-OS-01: Execution Engine
Lead & Pipeline Execution OS
"""

import sys
import os
from datetime import datetime, date
from typing import List, Dict, Any, Optional

try:
    from factory_core.modules.health import HealthDiagnosticsHandler
except ImportError:
    class HealthDiagnosticsHandler:
        def __init__(self, product_id: str):
            self.product_id = product_id
        def get_health_status(self) -> dict:
            return {
                "status": "HEALTHY",
                "product_id": self.product_id,
                "version": "1.0.0",
                "uptime_seconds": 0.0,
                "python_version": sys.version.split()[0],
                "platform": sys.platform,
                "genome_compliance": "GENOME_ALPHA_V1",
                "sla_guarantee_ms": 500
            }


class OperatingSystemEngine:
    """Core workflow execution engine for PIPE-OS-01 Lead & Pipeline Execution OS."""

    VALID_STAGES = {
        "PROSPECTING", "QUALIFICATION", "DISCOVERY",
        "PROPOSAL", "NEGOTIATION", "CLOSED_WON", "CLOSED_LOST"
    }
    VALID_STATUSES = {"OPEN", "WON", "LOST", "ON_HOLD"}
    VALID_QUALIFICATIONS = {"INCOMPLETE", "PARTIAL", "QUALIFIED", "DISQUALIFIED"}
    REQUIRED_FIELDS = {"opportunity_id", "account_name", "stage", "value"}

    STAGE_WEIGHTS = {
        "PROSPECTING": 0.2,
        "QUALIFICATION": 0.4,
        "DISCOVERY": 0.6,
        "PROPOSAL": 0.8,
        "NEGOTIATION": 1.0,
        "CLOSED_WON": 0.0,
        "CLOSED_LOST": 0.0
    }

    def __init__(self):
        self.product_id = "PIPE-OS-01"
        self.product_name = "Lead & Pipeline Execution OS"
        self.version = "1.0.0"
        self.health = HealthDiagnosticsHandler(self.product_id)

    def validate_opportunity(self, opp: Dict[str, Any], seen_ids: set) -> Dict[str, Any]:
        """Validates a single opportunity record and raises ValueError on invalid schema."""
        if not isinstance(opp, dict):
            raise ValueError(f"Malformed opportunity record: expected dict, received {type(opp).__name__}")

        # Validate required fields
        for field in self.REQUIRED_FIELDS:
            if field not in opp or opp[field] is None or str(opp[field]).strip() == "":
                raise ValueError(f"Missing required field: '{field}' in opportunity: {opp}")

        opp_id = str(opp["opportunity_id"]).strip()
        if opp_id in seen_ids:
            raise ValueError(f"Duplicate opportunity identifier detected: '{opp_id}'")
        seen_ids.add(opp_id)

        # Validate monetary value
        try:
            value = float(opp["value"])
            if value < 0:
                raise ValueError(f"Opportunity value cannot be negative: {value} in opportunity '{opp_id}'")
        except (ValueError, TypeError) as e:
            raise ValueError(f"Invalid value in opportunity '{opp_id}': {e}")

        # Validate stage
        stage = str(opp["stage"]).strip().upper()
        if stage not in self.VALID_STAGES:
            raise ValueError(f"Invalid stage '{stage}' in opportunity '{opp_id}'. Valid stages: {sorted(list(self.VALID_STAGES))}")

        # Validate status
        status = str(opp.get("status", "OPEN")).strip().upper()
        if status not in self.VALID_STATUSES:
            raise ValueError(f"Invalid status '{status}' in opportunity '{opp_id}'. Valid statuses: {sorted(list(self.VALID_STATUSES))}")

        # Validate qualification
        qual = str(opp.get("qualification", "INCOMPLETE")).strip().upper()
        if qual not in self.VALID_QUALIFICATIONS:
            raise ValueError(f"Invalid qualification '{qual}' in opportunity '{opp_id}'. Valid qualifications: {sorted(list(self.VALID_QUALIFICATIONS))}")

        # Validate date fields
        def parse_date(field_name: str) -> Optional[date]:
            val = opp.get(field_name)
            if val is not None and str(val).strip() != "":
                try:
                    return datetime.strptime(str(val).strip(), "%Y-%m-%d").date()
                except ValueError:
                    raise ValueError(f"Invalid date format '{val}' for field '{field_name}' in opportunity '{opp_id}'. Expected 'YYYY-MM-DD'.")
            return None

        stage_entered_at = parse_date("stage_entered_at")
        last_activity_at = parse_date("last_activity_at")
        next_action_due_at = parse_date("next_action_due_at")
        target_close_date = parse_date("target_close_date")

        owner = str(opp.get("owner", "Unassigned")).strip()
        next_action = str(opp.get("next_action", "")).strip()

        return {
            "opportunity_id": opp_id,
            "account_id": str(opp.get("account_id", opp_id)).strip(),
            "account_name": str(opp["account_name"]).strip(),
            "owner": owner,
            "stage": stage,
            "status": status,
            "value": value,
            "currency": str(opp.get("currency", "USD")).strip().upper(),
            "qualification": qual,
            "stage_entered_at": stage_entered_at,
            "last_activity_at": last_activity_at,
            "next_action": next_action,
            "next_action_due_at": next_action_due_at,
            "target_close_date": target_close_date
        }

    def process_opportunity(self, opp: Dict[str, Any], as_of_date: date) -> Dict[str, Any]:
        """Calculates stall indicators, priority scores, action items, and escalation tiers."""
        stage: str = opp["stage"]
        status: str = opp["status"]
        value: float = opp["value"]
        qual: str = opp["qualification"]
        owner: str = opp["owner"]
        next_action: str = opp["next_action"]
        next_action_due_at: Optional[date] = opp["next_action_due_at"]
        last_activity_at: Optional[date] = opp["last_activity_at"]
        stage_entered_at: Optional[date] = opp["stage_entered_at"]

        # Closed opportunities handling
        if stage in ["CLOSED_WON", "CLOSED_LOST"] or status in ["WON", "LOST"]:
            return {
                **opp,
                "stage_entered_at": stage_entered_at.isoformat() if stage_entered_at else None,
                "last_activity_at": last_activity_at.isoformat() if last_activity_at else None,
                "next_action_due_at": next_action_due_at.isoformat() if next_action_due_at else None,
                "target_close_date": opp["target_close_date"].isoformat() if opp["target_close_date"] else None,
                "days_in_stage": (as_of_date - stage_entered_at).days if stage_entered_at else 0,
                "days_inactive": (as_of_date - last_activity_at).days if last_activity_at else 0,
                "is_stalled": False,
                "is_overdue_followup": False,
                "is_missing_next_action": False,
                "is_unassigned_owner": False,
                "is_qualification_gap": False,
                "risk_level": "CLOSED",
                "priority_score": 0.0,
                "recommended_action": "Opportunity Closed — No Active Pipeline Action Required",
                "escalation_level": "NONE",
                "action_required": False
            }

        # Calculate time metrics
        days_in_stage = (as_of_date - stage_entered_at).days if stage_entered_at else 0
        days_inactive = (as_of_date - last_activity_at).days if last_activity_at else 0
        followup_overdue_days = (as_of_date - next_action_due_at).days if next_action_due_at else 0

        # Operational defect checks
        is_stalled = (days_inactive > 14) or (days_in_stage > 30)
        is_missing_next_action = (not next_action or next_action.lower() in ["none", "n/a", "tbd", ""])
        is_overdue_followup = (followup_overdue_days > 0)
        is_unassigned_owner = (not owner or owner.lower() in ["unassigned", "none", ""])
        
        # Qualification gap: advanced stage with incomplete qualification
        advanced_stages = {"DISCOVERY", "PROPOSAL", "NEGOTIATION"}
        is_qualification_gap = (stage in advanced_stages and qual in ["INCOMPLETE", "DISQUALIFIED"])

        # Determine Risk Multiplier & Level
        risk_multiplier = 1.0
        gaps_count = 0

        if is_stalled:
            risk_multiplier += 0.6
            gaps_count += 1
        if is_missing_next_action:
            risk_multiplier += 0.4
            gaps_count += 1
        if is_overdue_followup:
            risk_multiplier += 0.4
            gaps_count += 1
        if is_qualification_gap:
            risk_multiplier += 0.5
            gaps_count += 1
        if is_unassigned_owner:
            risk_multiplier += 0.4
            gaps_count += 1

        stage_weight = self.STAGE_WEIGHTS.get(stage, 0.5)
        priority_score = round(value * stage_weight * risk_multiplier, 2)

        # Risk Classification
        if (value >= 25000.0 and (is_stalled or stage == "NEGOTIATION")) or gaps_count >= 3:
            risk_level = "CRITICAL"
        elif gaps_count >= 2 or is_stalled or (stage in ["PROPOSAL", "NEGOTIATION"] and is_overdue_followup):
            risk_level = "HIGH"
        elif gaps_count == 1:
            risk_level = "MEDIUM"
        else:
            risk_level = "LOW"

        # Action & Escalation Assignment
        action_required = (gaps_count > 0 or is_stalled or is_missing_next_action or is_overdue_followup or is_unassigned_owner)
        
        if risk_level == "CRITICAL":
            escalation_level = "TIER_3_EXECUTIVE_INTERVENTION"
            recommended_action = "Immediate VP Sales & Executive Sponsor Intervention to Salvage Deal"
        elif risk_level == "HIGH":
            escalation_level = "TIER_2_MANAGER_ESCALATION"
            recommended_action = "Sales Manager Pipeline Review & Rep Coaching on Next Milestones"
        elif risk_level == "MEDIUM":
            escalation_level = "TIER_1_REP_ALERT"
            if is_missing_next_action:
                recommended_action = "Assign Explicit Next Action and Scheduled Meeting Date"
            elif is_overdue_followup:
                recommended_action = "Execute Overdue Follow-Up and Log Customer Interaction"
            else:
                recommended_action = "Validate Qualification Criteria before Advancing Stage"
        else:
            escalation_level = "NONE"
            recommended_action = "Opportunity On Track — Maintain Scheduled Action Cadence"

        return {
            **opp,
            "stage_entered_at": stage_entered_at.isoformat() if stage_entered_at else None,
            "last_activity_at": last_activity_at.isoformat() if last_activity_at else None,
            "next_action_due_at": next_action_due_at.isoformat() if next_action_due_at else None,
            "target_close_date": opp["target_close_date"].isoformat() if opp["target_close_date"] else None,
            "days_in_stage": days_in_stage,
            "days_inactive": days_inactive,
            "is_stalled": is_stalled,
            "is_overdue_followup": is_overdue_followup,
            "is_missing_next_action": is_missing_next_action,
            "is_unassigned_owner": is_unassigned_owner,
            "is_qualification_gap": is_qualification_gap,
            "risk_level": risk_level,
            "priority_score": priority_score,
            "recommended_action": recommended_action,
            "escalation_level": escalation_level,
            "action_required": action_required
        }

    def execute_workflow(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """
        Executes end-to-end pipeline execution workflow.
        Accepts: {"opportunities": List[dict], "as_of_date": Optional[str]}
        Returns: Structured operational audit with pipeline analytics, defect counts, and priority queue.
        """
        if not isinstance(payload, dict):
            return {
                "status": "ERROR",
                "product_id": self.product_id,
                "error": f"Invalid payload: expected dict, received {type(payload).__name__}",
                "metrics": self.health.get_health_status()
            }

        raw_opportunities = payload.get("opportunities", [])
        if not isinstance(raw_opportunities, list):
            return {
                "status": "ERROR",
                "product_id": self.product_id,
                "error": "Field 'opportunities' must be a list",
                "metrics": self.health.get_health_status()
            }

        # Parse audit reference date
        as_of_str = payload.get("as_of_date")
        if as_of_str:
            try:
                as_of_date = datetime.strptime(str(as_of_str).strip(), "%Y-%m-%d").date()
            except ValueError:
                return {
                    "status": "ERROR",
                    "product_id": self.product_id,
                    "error": f"Invalid as_of_date format '{as_of_str}'. Expected 'YYYY-MM-DD'.",
                    "metrics": self.health.get_health_status()
                }
        else:
            as_of_date = date.today()

        seen_ids = set()
        validated_opportunities = []
        try:
            for opp in raw_opportunities:
                cleaned = self.validate_opportunity(opp, seen_ids)
                processed = self.process_opportunity(cleaned, as_of_date)
                validated_opportunities.append(processed)
        except ValueError as e:
            return {
                "status": "VALIDATION_FAILED",
                "product_id": self.product_id,
                "error": str(e),
                "metrics": self.health.get_health_status()
            }

        # Filter actionable items sorted by priority_score descending
        action_queue = [
            opp for opp in validated_opportunities if opp["action_required"]
        ]
        action_queue.sort(key=lambda x: x["priority_score"], reverse=True)

        # Aggregate Pipeline Metrics
        total_count = len(validated_opportunities)
        total_val = sum(opp["value"] for opp in validated_opportunities)
        open_opps = [opp for opp in validated_opportunities if opp["status"] == "OPEN" and opp["stage"] not in ["CLOSED_WON", "CLOSED_LOST"]]
        active_val = sum(opp["value"] for opp in open_opps)

        stalled_opps = [opp for opp in open_opps if opp["is_stalled"]]
        stalled_val = sum(opp["value"] for opp in stalled_opps)

        missing_next_action_count = sum(1 for opp in open_opps if opp["is_missing_next_action"])
        overdue_followup_count = sum(1 for opp in open_opps if opp["is_overdue_followup"])
        unassigned_owner_count = sum(1 for opp in open_opps if opp["is_unassigned_owner"])
        qualification_gaps_count = sum(1 for opp in open_opps if opp["is_qualification_gap"])

        # Stage Distribution
        stage_values = {s: 0.0 for s in self.VALID_STAGES}
        stage_counts = {s: 0 for s in self.VALID_STAGES}
        for opp in validated_opportunities:
            stg = opp["stage"]
            stage_values[stg] = round(stage_values[stg] + opp["value"], 2)
            stage_counts[stg] += 1

        operational_summary = {
            "as_of_date": as_of_date.isoformat(),
            "total_opportunities_audited": total_count,
            "total_pipeline_value": round(total_val, 2),
            "active_pipeline_value": round(active_val, 2),
            "stalled_pipeline_value": round(stalled_val, 2),
            "stalled_pipeline_ratio_percentage": round((stalled_val / active_val * 100) if active_val > 0 else 0.0, 1),
            "missing_next_action_count": missing_next_action_count,
            "overdue_followup_count": overdue_followup_count,
            "unassigned_owner_count": unassigned_owner_count,
            "qualification_gaps_count": qualification_gaps_count,
            "action_queue_count": len(action_queue),
            "stage_distribution_value": stage_values,
            "stage_distribution_count": stage_counts
        }

        return {
            "status": "SUCCESS",
            "product_id": self.product_id,
            "product_name": self.product_name,
            "version": self.version,
            "summary": operational_summary,
            "priority_action_queue": action_queue,
            "opportunities": validated_opportunities,
            "metrics": self.health.get_health_status()
        }
