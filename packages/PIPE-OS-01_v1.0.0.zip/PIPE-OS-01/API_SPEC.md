# PIPE-OS-01 — INTERFACE SPECIFICATION & INTEGRATION BOUNDARY

> **Product ID**: PIPE-OS-01  
> **Document Type**: Technical Interface Specification / Integration Contract  
> **Status**: Interface Contract Specification (Self-Hosted / Local Execution)  
> **Note**: This document defines the payload contracts for connecting internal CRM and pipeline data sources (Salesforce, HubSpot, Pipedrive, internal databases) to PIPE-OS-01. Live third-party API adapters are executed within customer infrastructure.  

---

## 1. INGESTION DATA CONTRACT (JSON SCHEMA)

### Inbound Opportunities Array Payload: `POST /api/v1/pipeline/ingest`
```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "title": "PipeOSInboundOpportunities",
  "type": "object",
  "required": ["opportunities"],
  "properties": {
    "as_of_date": {
      "type": "string",
      "format": "date",
      "description": "Optional audit reference date (YYYY-MM-DD). Defaults to execution date."
    },
    "opportunities": {
      "type": "array",
      "items": {
        "type": "object",
        "required": ["opportunity_id", "account_name", "stage", "value"],
        "properties": {
          "opportunity_id": { "type": "string" },
          "account_id": { "type": "string" },
          "account_name": { "type": "string" },
          "owner": { "type": "string", "default": "Unassigned" },
          "stage": { 
            "type": "string",
            "enum": ["PROSPECTING", "QUALIFICATION", "DISCOVERY", "PROPOSAL", "NEGOTIATION", "CLOSED_WON", "CLOSED_LOST"]
          },
          "status": {
            "type": "string",
            "enum": ["OPEN", "WON", "LOST", "ON_HOLD"],
            "default": "OPEN"
          },
          "value": { "type": "number", "minimum": 0 },
          "currency": { "type": "string", "default": "USD" },
          "qualification": {
            "type": "string",
            "enum": ["INCOMPLETE", "PARTIAL", "QUALIFIED", "DISQUALIFIED"],
            "default": "INCOMPLETE"
          },
          "stage_entered_at": { "type": "string", "format": "date" },
          "last_activity_at": { "type": "string", "format": "date" },
          "next_action": { "type": "string" },
          "next_action_due_at": { "type": "string", "format": "date" },
          "target_close_date": { "type": "string", "format": "date" }
        }
      }
    }
  }
}
```

---

## 2. OUTBOUND AUDIT EXECUTION CONTRACT

### Response Payload Schema: `200 OK`
```json
{
  "status": "SUCCESS",
  "product_id": "PIPE-OS-01",
  "product_name": "Lead & Pipeline Execution OS",
  "version": "1.0.0",
  "summary": {
    "as_of_date": "2026-08-17",
    "total_opportunities_audited": 10,
    "total_pipeline_value": 311500.00,
    "active_pipeline_value": 257500.00,
    "stalled_pipeline_value": 110000.00,
    "stalled_pipeline_ratio_percentage": 42.7,
    "missing_next_action_count": 1,
    "overdue_followup_count": 2,
    "unassigned_owner_count": 1,
    "qualification_gaps_count": 1,
    "action_queue_count": 4,
    "stage_distribution_value": {
      "PROSPECTING": 12000.00,
      "QUALIFICATION": 15000.00,
      "DISCOVERY": 40500.00,
      "PROPOSAL": 73000.00,
      "NEGOTIATION": 117000.00,
      "CLOSED_WON": 35000.00,
      "CLOSED_LOST": 19000.00
    }
  },
  "priority_action_queue": [
    {
      "opportunity_id": "OPP-2026-101",
      "account_name": "Apex Manufacturing Ltd",
      "value": 65000.00,
      "stage": "NEGOTIATION",
      "owner": "Marcus Bell (Account Executive)",
      "is_stalled": true,
      "risk_level": "CRITICAL",
      "priority_score": 104000.00,
      "recommended_action": "Immediate VP Sales & Executive Sponsor Intervention to Salvage Deal",
      "escalation_level": "TIER_3_EXECUTIVE_INTERVENTION"
    }
  ],
  "metrics": {
    "status": "HEALTHY",
    "product_id": "PIPE-OS-01",
    "version": "1.0.0"
  }
}
```

---

## 3. WEBHOOK EVENT CONTRACTS (OUTBOUND ALERTS)

1. **`pipeline.stall.detected`**: Dispatched when an opportunity exceeds 14 days of inactivity or 30 days in stage.
2. **`pipeline.executive_escalation.triggered`**: Dispatched when a critical deal ($\ge \$25,000$) enters `TIER_3_EXECUTIVE_INTERVENTION`.

---

*PIPE-OS-01 API Specification v1.0.0 — Authoritative.*
