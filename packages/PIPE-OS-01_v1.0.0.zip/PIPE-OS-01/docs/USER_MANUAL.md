# PIPE-OS-01 — USER MANUAL & OPERATOR GUIDE

> **Product ID**: PIPE-OS-01  
> **Audience**: Sales Operations Leads, Sales Managers, Account Executives  

---

## 1. DAILY & WEEKLY OPERATOR WORKFLOW

1. **Step 1 — Morning Health Check**:
   ```bash
   python src/cli.py health
   ```
   Confirm system status returns `HEALTHY`.

2. **Step 2 — Generate Pipeline Summary Table**:
   ```bash
   python src/cli.py summary
   ```
   Inspect the `OPERATIONAL DEFECT INVENTORY` and `PRIORITY ACTION QUEUE`.

3. **Step 3 — Actioning Gaps by Priority**:
   - Focus first on Tier-3 Critical deals ($\ge \$25,000$ stalled in Proposal/Negotiation).
   - Address Tier-2 Stalled opportunities during 1-on-1 rep pipeline reviews.
   - Enforce Tier-1 Rep alerts (ensure every open opportunity has an explicit next action and scheduled due date).

4. **Step 4 — Update CRM Records**:
   Log customer commitments and update next action dates in your primary CRM system.

---

*PIPE-OS-01 User Manual v1.0.0 — Authoritative.*
