# PIPE-OS-01: Lead & Pipeline Execution OS

> **Evolvith Wave 2 Focused Operating System**  
> **Commercial Tier**: $99 USD One-Time Perpetual Commercial License  
> **Parent Upgrade Vector**: `REV-OS-01 Autonomous Revenue Operations OS` ($249)  
> **Runtime**: Python 3.9+ | 100% Self-Hosted / Private Cloud  

---

## 1. WHAT PROBLEM PIPE-OS-01 SOLVES

In B2B sales organizations, pipeline decay and deal slippage occur quietly. CRMs store opportunities passively, but fail to enforce operational follow-up discipline, resulting in:
- High-value deals going dark without rep follow-up.
- Opportunities advancing through pipeline stages without genuine qualification.
- Unassigned deals and missing next actions causing revenue leakage.
- Sales managers lacking early warning triggers before end-of-quarter deal losses.

**PIPE-OS-01** provides an immediate, executable operating system that ingests open sales pipeline data, deterministically detects deal stalls, calculates risk-weighted priority rankings, flags missing next actions, and triggers 4-tier manager escalation cadences.

---

## 2. WHAT DATA PIPE-OS-01 REQUIRES

PIPE-OS-01 requires standard opportunity records in JSON format (exported from Salesforce, HubSpot, Pipedrive, or internal databases):
- `opportunity_id` *(string, required)*: Unique opportunity identifier (e.g. "OPP-2026-101")
- `account_name` *(string, required)*: Prospect or customer account name
- `stage` *(string, required)*: `PROSPECTING`, `QUALIFICATION`, `DISCOVERY`, `PROPOSAL`, `NEGOTIATION`, `CLOSED_WON`, `CLOSED_LOST`
- `value` *(number, required)*: Deal gross value / ARR amount
- `owner` *(string, optional)*: Assigned sales rep / account executive
- `qualification` *(string, optional)*: `INCOMPLETE`, `PARTIAL`, `QUALIFIED`, `DISQUALIFIED`
- `last_activity_at` *(string, optional)*: Last customer touchpoint date (`YYYY-MM-DD`)
- `next_action` *(string, optional)*: Specific next planned action
- `next_action_due_at` *(string, optional)*: Scheduled date for next action (`YYYY-MM-DD`)

---

## 3. WHAT PIPE-OS-01 DOES & PRODUCES

1. **Deterministic Stall Detection**: Flags deals inactive > 14 days or stuck in a single stage > 30 days.
2. **Defect Audit**: Identifies missing next actions, overdue follow-ups, qualification gaps, and unassigned owners.
3. **Risk-Weighted Priority Matrix**: Computes $\text{Value} \times \text{Stage Weight} \times \text{Risk Factor}$ to rank deals requiring immediate managerial triage.
4. **4-Tier Action & Escalation Dispatch**: Prescribes explicit rep actions up to executive sponsor deal interventions.
5. **Executive Pipeline Summary**: Computes total active pipeline, stalled exposure ratios, and stage distribution tables.

---

## 4. WHAT PIPE-OS-01 DOES NOT DO

- It is **NOT** a CRM replacement or contact database.
- It does **NOT** send automated marketing emails or outbound cold sequences.
- It does **NOT** perform statistical machine-learning revenue forecasting (use `REV-OS-01`).
- It does **NOT** transmit any sales data to Evolvith servers (100% self-hosted).

---

## 5. QUICKSTART INSTALLATION & USAGE

### Step 1: Run Quickstart Installer
```bash
python install.py
```

### Step 2: Verify System Health
```bash
python src/cli.py health
```

### Step 3: Run Pipeline Audit on Sample Data
```bash
python src/cli.py summary
```

### Step 4: Run on Custom Pipeline Dataset
```bash
python src/cli.py run --input path/to/my_pipeline.json --output reports/pipeline_audit_output.json
```

---

## 6. CLAIM GOVERNANCE & DISCLAIMERS

> **MODELED TARGET — NOT HISTORICAL PERFORMANCE**  
> All quantitative metrics (e.g. 35% reduction in stalled deal aging, 50% faster escalation) represent modeled design targets under standard operational compliance, not historical performance guarantees.

---

*PIPE-OS-01 User Guide v1.0.0 — Authoritative.*
