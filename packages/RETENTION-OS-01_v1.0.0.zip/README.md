# RETENTION-OS-01 Customer Retention & Churn Alert OS
Version 1.0.0 — Production Distribution Package

## System Description
Early-Warning Usage Decay Detection & Health Scoring Engine

## Quickstart Deployment
Execute automated installation:
```bash
python install.py
```

## Commercial License
One-Time Perpetual Commercial License with unlimited internal seats.
